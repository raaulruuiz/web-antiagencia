chrome.runtime.sendMessage({ type: 'getBibViewerImage' }, ({ data }) => {
  if (!data?.dataUrl) return;
  const img = document.getElementById('img');
  img.src = data.dataUrl;

  document.getElementById('dl').addEventListener('click', () => {
    chrome.downloads.download({ url: data.dataUrl, filename: data.filename || 'captura.png' });
  });

  const sendBtn = document.getElementById('send');
  sendBtn.addEventListener('click', () => {
    sendBtn.disabled = true;
    sendBtn.textContent = 'Subiendo…';
    chrome.runtime.sendMessage({ type: 'bibUploadFile', name: data.filename || `captura_${Date.now()}.png`, dataUrl: data.dataUrl }, resp => {
      if (resp?.ok && resp.id) {
        chrome.tabs.create({ url: `https://antiagencia.es/admin/biblioteca/${resp.id}` });
        window.close();
      } else {
        sendBtn.textContent = 'Error';
        setTimeout(() => { sendBtn.disabled = false; sendBtn.textContent = 'Llevar a Biblioteca'; }, 2000);
      }
    });
  });
});
document.getElementById('close').addEventListener('click', () => window.close());
document.addEventListener('keydown', e => { if (e.key === 'Escape') window.close(); });
