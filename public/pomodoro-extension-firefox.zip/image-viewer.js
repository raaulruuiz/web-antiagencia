chrome.runtime.sendMessage({ type: 'getBibViewerImage' }, ({ data }) => {
  if (!data?.dataUrl) return;
  const img = document.getElementById('img');
  img.src = data.dataUrl;
  document.getElementById('dl').addEventListener('click', () => {
    chrome.downloads.download({ url: data.dataUrl, filename: data.filename || 'captura.png' });
  });
});
document.getElementById('close').addEventListener('click', () => window.close());
document.addEventListener('keydown', e => { if (e.key === 'Escape') window.close(); });
