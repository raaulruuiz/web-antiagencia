const SUPABASE_URL   = 'https://wphvmyqsxicyoifrlevt.supabase.co';
const SUPABASE_ANON  = 'sb_publishable_cB3mpag9moVvhekQG6GBWw_ogz_nb9M';
const API_BASE       = 'https://automatizaciones-production-a376.up.railway.app';

// ── Elements (lazy getters to avoid null-at-load issues) ─────────────────────
const loginView      = document.getElementById('loginView');
const sessionView    = document.getElementById('sessionView');
const emailInput     = document.getElementById('emailInput');
const passInput      = document.getElementById('passwordInput');
const loginBtn       = document.getElementById('loginBtn');
const loginError     = document.getElementById('loginError');
const logoutBtn      = document.getElementById('logoutBtn');
const wildcardToggle = document.getElementById('wildcardToggle');
const pomSelect      = document.getElementById('pomodoroSelect');
const addUrlBtn      = document.getElementById('addUrlBtn');
// Dynamic elements: queried inline to avoid stale null refs
const $ = id => document.getElementById(id);

// ── State ─────────────────────────────────────────────────────────────────────
let wildcardMode = true;   // true = todo el dominio, false = URL exacta
let currentTab   = null;
let pomodorosMap = {};     // id → pomodoro data (blocked_urls, etc.)
let sessions     = [];
let strictMode   = { enabled: false, method: { type: 'none' } };
let pauseState   = {};     // state for strict-mode verification flow

// ── Helpers ───────────────────────────────────────────────────────────────────
function formatTime(ms) {
  if (ms <= 0) return '00:00';
  const s = Math.floor(ms / 1000);
  return `${Math.floor(s / 60).toString().padStart(2, '0')}:${(s % 60).toString().padStart(2, '0')}`;
}

function extractDomain(url) {
  try {
    return new URL(url).hostname.replace(/^www\./, '');
  } catch { return url; }
}

function getUrlToAdd(fullUrl) {
  if (wildcardMode) return extractDomain(fullUrl);
  try {
    const u = new URL(fullUrl);
    return (u.hostname + u.pathname).replace(/^www\./, '').replace(/\/$/, '');
  } catch { return fullUrl; }
}

function updateWildcardUI() {
  if (wildcardToggle) wildcardToggle.classList.toggle('on', wildcardMode);
  const wildcardLabel = $('wildcardLabel');
  if (wildcardLabel) wildcardLabel.textContent = wildcardMode ? 'Todo el dominio' : 'URL exacta';
  const urlDisplay = $('currentUrlDisplay');
  if (urlDisplay && currentTab?.url) urlDisplay.textContent = getUrlToAdd(currentTab.url);
}

function renderStatus({ active, ends_at }) {
  const pomStatusEl = $('pomStatus');
  const countdownEl = $('countdown');
  if (!pomStatusEl || !countdownEl) return;
  if (active && ends_at) {
    const rem = new Date(ends_at).getTime() - Date.now();
    if (rem > 0) {
      pomStatusEl.textContent = 'Modo trabajo activo';
      pomStatusEl.classList.add('active');
      countdownEl.textContent = formatTime(rem);
      return;
    }
  }
  pomStatusEl.textContent = 'Inactivo';
  pomStatusEl.classList.remove('active');
  countdownEl.textContent = '';
}

function setFeedback(msg, type) {
  const addFeedback = $('addFeedback');
  if (!addFeedback) return;
  addFeedback.textContent = msg;
  addFeedback.className = type || '';
}

// ── Already-added check ───────────────────────────────────────────────────────

function updateAddBtn() {
  if (!pomSelect || !addUrlBtn) return;
  const pomId = pomSelect.value;
  if (!pomId || !currentTab?.url) { addUrlBtn.disabled = true; return; }
  const pom = pomodorosMap[pomId];
  if (!pom) { addUrlBtn.disabled = true; return; }
  const urlToAdd = getUrlToAdd(currentTab.url);
  const alreadyAdded = (pom.blocked_urls || []).some(u => {
    if (u.url === urlToAdd) return true;
    if (u.wildcard && urlToAdd.endsWith('.' + u.url)) return true;
    return false;
  });
  if (alreadyAdded) {
    addUrlBtn.disabled = true;
    addUrlBtn.textContent = 'Ya añadida';
    setFeedback('', '');
  } else {
    addUrlBtn.disabled = false;
    addUrlBtn.textContent = 'Añadir a Pomodoro';
    setFeedback('', '');
  }
}

// ── Math operations (for pause method) ───────────────────────────────────────

function rng(a, b) { return Math.floor(Math.random() * (b - a + 1)) + a; }
function generateOp(d) {
  if (d <= 2) { const a=rng(1,d*10),b=rng(1,d*10); return {q:`${a} + ${b}`,a:a+b}; }
  if (d <= 4) {
    const a=rng(2,9),b=rng(2,9);
    if (Math.random()>.5) return {q:`${a} × ${b}`,a:a*b};
    const n=rng(15,50),s=rng(1,n-1); return {q:`${n} − ${s}`,a:n-s};
  }
  if (d <= 6) { const a=rng(3,9),b=rng(3,9),c=rng(1,15); return {q:`${a} × ${b} + ${c}`,a:a*b+c}; }
  const a=rng(3,9),b=rng(3,9),c=rng(2,9),e=rng(1,10); return {q:`(${a}+${b}) × ${c} − ${e}`,a:(a+b)*c-e};
}
function generateOperations(count, ascending) {
  return Array.from({length:count},(_,i)=>generateOp(ascending?Math.round(1+(9*i)/Math.max(count-1,1)):5));
}

// ── Sessions ──────────────────────────────────────────────────────────────────

async function loadSessions() {
  const { userToken } = await chrome.storage.local.get('userToken');
  if (!userToken) return;
  try {
    const res = await fetch(`${API_BASE}/pomodoro/my-sessions`, {
      headers: { 'Authorization': `Bearer ${userToken}` },
    });
    if (!res.ok) return;
    sessions = await res.json();
    renderSessions();
  } catch(e) { console.warn('[Sessions]', e.message); }
}

async function loadStrictMode() {
  const { userToken } = await chrome.storage.local.get('userToken');
  if (!userToken) return;
  try {
    const res = await fetch(`${API_BASE}/pomodoro/strict-mode`, {
      headers: { 'Authorization': `Bearer ${userToken}` },
    });
    if (!res.ok) return;
    strictMode = await res.json();
    renderStrictModeToggle();
    renderSessions(); // re-render to update pause buttons
  } catch(e) { console.warn('[StrictMode]', e.message); }
}

function renderStrictModeToggle() {
  const el = document.getElementById('strictModeToggle');
  const label = document.getElementById('strictModeLabel');
  if (!el || !label) return;
  el.classList.toggle('on', strictMode.enabled);
  label.textContent = strictMode.enabled ? 'Modo estricto activado' : 'Modo estricto desactivado';
}

function renderSessions() {
  const section    = document.getElementById('sessionsSection');
  const activeList = document.getElementById('activePomList');
  if (!section || !activeList) return;

  section.style.display = sessions.length ? 'block' : 'none';

  activeList.innerHTML = sessions.length
    ? sessions.map(renderPomCard).join('')
    : '<p style="font-size:0.72rem;color:#52525b;padding:4px 0">Sin Pomodoros.</p>';

  // Auto-focus any pause input
  setTimeout(() => {
    const inp = document.querySelector('.pause-input[data-autofocus]');
    if (inp) inp.focus();
  }, 30);
}

function renderPomCard(p) {
  const enabled = p.enabled !== false;
  const isRunning = enabled && p.is_running;
  const cd = p.ends_at ? formatTime(new Date(p.ends_at).getTime() - Date.now()) : null;

  // With strict mode on, you cannot disable an active pomodoro
  const strictLocked = strictMode.enabled && enabled;
  const toggleHtml = `<button class="toggle-btn ${enabled ? 'on' : ''}" ${strictLocked ? 'disabled title="Desactiva el modo estricto primero"' : `data-action="togglePom" data-id="${p.id}" title="${enabled ? 'Desactivar' : 'Activar'}"`}>
    <div class="toggle-thumb"></div>
  </button>`;

  const rightHtml = isRunning && cd ? `<span class="pom-cd" id="cd-${p.id}">${cd}</span>` : '';

  return `<div class="pom-card" id="pom-card-${p.id}" style="${!enabled ? 'opacity:0.5' : ''}">
    <div class="pom-row">
      ${toggleHtml}
      <span class="pom-name" style="flex:1;margin-left:8px">${p.name}</span>
      <div class="pom-row-right">${rightHtml}</div>
    </div>
    <div style="margin-top:6px;margin-left:36px">
      <button class="edit-link" data-action="openEdit" data-id="${p.id}">Editar</button>
    </div>
  </div>`;
}

// ── Session actions ───────────────────────────────────────────────────────────

async function togglePom(id) {
  const { userToken } = await chrome.storage.local.get('userToken');
  try {
    const res = await fetch(`${API_BASE}/pomodoro/sessions/${id}/toggle`, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${userToken}`, 'Content-Type': 'application/json' },
    });
    const data = await res.json();
    if (!res.ok) return;
    const p = sessions.find(s => s.id === id);
    if (p) p.enabled = data.enabled;
    renderSessions();
  } catch(e) { console.warn('Toggle:', e.message); }
}

// ── Sessions event delegation ─────────────────────────────────────────────────

const sessionsSectionEl = document.getElementById('sessionsSection');
if (sessionsSectionEl) {
  sessionsSectionEl.addEventListener('click', e => {
    const btn = e.target.closest('[data-action]');
    if (!btn) return;
    const { action, id } = btn.dataset;
    if (action === 'togglePom')          togglePom(id);
    else if (action === 'openEdit')      chrome.tabs.create({ url: `https://antiagencia.es/admin/pomodoro?edit=${id}` });
    else if (action === 'strictToggle')  handleStrictToggle();
    else if (action === 'strictEmailSend')   strictEmailSend();
    else if (action === 'strictVerifyCode')  strictVerifyCodeAction();
    else if (action === 'strictCheckOp')     strictCheckOp();
  });

  sessionsSectionEl.addEventListener('keydown', e => {
    if (e.key !== 'Enter') return;
    const inp = e.target.closest('[data-action-input]');
    if (!inp) return;
    if (inp.dataset.actionInput === 'strictVerifyCode') strictVerifyCodeAction();
    else if (inp.dataset.actionInput === 'strictCheckOp') strictCheckOp();
  });

  sessionsSectionEl.addEventListener('input', e => {
    const sInp = e.target.closest('[data-action-input="strictVerifyCode"]');
    if (sInp) sInp.value = sInp.value.toUpperCase();
  });
}

// Countdown ticker for sessions
setInterval(() => {
  sessions.forEach(p => {
    if (p.is_running && p.ends_at) {
      const el = document.getElementById(`cd-${p.id}`);
      if (el) el.textContent = formatTime(new Date(p.ends_at).getTime() - Date.now());
    }
  });
}, 1000);

// ── Pomodoros list ────────────────────────────────────────────────────────────
async function loadPomodoros(token) {
  try {
    const res = await fetch(`${API_BASE}/pomodoro/my-pomodoros`, {
      headers: { 'Authorization': `Bearer ${token}` },
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Error');

    pomodorosMap = {};
    if (!pomSelect || !addUrlBtn) return;
    pomSelect.innerHTML = '';
    if (!data.length) {
      pomSelect.innerHTML = '<option value="">Sin Pomodoros disponibles</option>';
      addUrlBtn.disabled = true;
      return;
    }
    data.forEach(p => {
      pomodorosMap[p.id] = p;
      const opt = document.createElement('option');
      opt.value = p.id;
      opt.textContent = p.name + (p.is_universal ? ' (Universal)' : ' (Privado)');
      pomSelect.appendChild(opt);
    });
    updateAddBtn();
  } catch {
    if (pomSelect) pomSelect.innerHTML = '<option value="">Error al cargar</option>';
    if (addUrlBtn) addUrlBtn.disabled = true;
  }
}

if (pomSelect) pomSelect.addEventListener('change', updateAddBtn);

// ── Show / hide views ─────────────────────────────────────────────────────────
function showSession(email, token) {
  loginView.style.display = 'none';
  if (sessionView) sessionView.style.display = 'flex';
  const userEmailEl = $('userEmail');
  if (userEmailEl) userEmailEl.textContent = email;

  // Get current tab
  chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
    currentTab = tab;
    const urlDisplay = $('currentUrlDisplay');
    if (urlDisplay) urlDisplay.textContent = tab?.url ? getUrlToAdd(tab.url) : '—';
  });

  // Status ticker
  chrome.storage.local.get(['active', 'ends_at'], renderStatus);
  setInterval(() => chrome.storage.local.get(['active', 'ends_at'], renderStatus), 1000);

  // Load pomodoros for the dropdown
  loadPomodoros(token);

  // Load sessions (Mis Pomodoros section) and auto-refresh every 30s
  loadSessions();
  loadStrictMode();
  setInterval(loadSessions, 30000);
}

function showLogin() {
  loginView.style.display = 'flex';
  sessionView.style.display = 'none';
}

// ── Init ──────────────────────────────────────────────────────────────────────
// Helper: read Supabase session directly from localStorage of the antiagencia.es tab
function readSessionFromTab(tab) {
  return chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: () => {
      try {
        for (let i = 0; i < localStorage.length; i++) {
          const key = localStorage.key(i);
          if (key && (key.startsWith('sb-') || key.includes('supabase')) && key.endsWith('-auth-token')) {
            const raw = localStorage.getItem(key);
            if (!raw) continue;
            const s = JSON.parse(raw);
            if (s?.access_token) return {
              token: s.access_token,
              refreshToken: s.refresh_token,
              email: s.user?.email,
              expiresAt: s.expires_at ? s.expires_at * 1000 - 60000 : null,
            };
          }
        }
      } catch (_) {}
      return null;
    },
  }).then(r => r?.[0]?.result || null).catch(() => null);
}

chrome.storage.local.get(['userEmail', 'userToken'], async ({ userEmail, userToken }) => {
  // Always try the antiagencia.es tab first — avoids stale/expired tokens
  // (MV3 service workers can be killed while Supabase rotates refresh tokens,
  // leaving storage with an invalid token)
  try {
    const tabs = await chrome.tabs.query({ url: '*://antiagencia.es/*' });
    const tab = tabs[0];
    if (tab) {
      const session = await readSessionFromTab(tab);
      if (session) {
        await chrome.storage.local.set({
          userToken:        session.token,
          userRefreshToken: session.refreshToken,
          userEmail:        session.email,
          userTokenExpiry:  session.expiresAt,
        });
        showSession(session.email, session.token);
        return;
      }
    }
  } catch (_) {}

  // Fall back to cached storage (e.g., antiagencia.es tab is not open)
  if (userEmail && userToken) {
    showSession(userEmail, userToken);
    return;
  }

  showLogin();
});

// ── Login ─────────────────────────────────────────────────────────────────────
if (loginBtn) loginBtn.addEventListener('click', async () => {
  const email    = emailInput.value.trim();
  const password = passInput.value;
  if (!email || !password) return;

  loginBtn.disabled = true;
  loginBtn.textContent = 'Entrando…';
  loginError.style.display = 'none';

  try {
    const res  = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=password`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'apikey': SUPABASE_ANON },
      body: JSON.stringify({ email, password }),
    });
    const data = await res.json();

    if (!res.ok || !data.access_token) {
      loginError.textContent = data.error_description || 'Credenciales incorrectas';
      loginError.style.display = 'block';
      return;
    }

    await chrome.storage.local.set({
      userToken:        data.access_token,
      userRefreshToken: data.refresh_token,
      userEmail:        data.user.email,
      userTokenExpiry:  Date.now() + (data.expires_in - 60) * 1000,
    });

    chrome.runtime.sendMessage({ type: 'refresh' });
    showSession(data.user.email, data.access_token);
  } catch {
    loginError.textContent = 'Error de conexión';
    loginError.style.display = 'block';
  } finally {
    loginBtn.disabled    = false;
    loginBtn.textContent = 'Entrar';
  }
});

if (passInput) passInput.addEventListener('keydown', e => { if (e.key === 'Enter') loginBtn?.click(); });

// ── Logout ────────────────────────────────────────────────────────────────────
if (logoutBtn) logoutBtn.addEventListener('click', async () => {
  await chrome.storage.local.remove(['userToken', 'userRefreshToken', 'userEmail', 'userTokenExpiry']);
  chrome.runtime.sendMessage({ type: 'refresh' });
  showLogin();
  emailInput.value = '';
  passInput.value  = '';
});

// ── Wildcard toggle ───────────────────────────────────────────────────────────
if (wildcardToggle) wildcardToggle.addEventListener('click', () => {
  wildcardMode = !wildcardMode;
  updateWildcardUI();
  updateAddBtn();
});

// ── Strict mode toggle ────────────────────────────────────────────────────────

async function handleStrictToggle() {
  if (strictMode.enabled) {
    // Need to verify before disabling
    const type = strictMode.method?.type || 'none';
    if (type === 'none') {
      await doStrictToggle();
    } else if (type === 'email') {
      pauseState['__strict__'] = { step: 'email-send', useStrictEmail: true, isStrictToggle: true };
      renderStrictVerifySection();
    } else if (type === 'operations') {
      const ops = generateOperations(strictMode.method?.count || 5, strictMode.method?.ascending !== false);
      pauseState['__strict__'] = { step: 'operations', ops, opIdx: 0, restart_on_fail: strictMode.method?.restart_on_fail || false, isStrictToggle: true };
      renderStrictVerifySection();
    }
  } else {
    await doStrictToggle();
  }
}

async function doStrictToggle() {
  const { userToken } = await chrome.storage.local.get('userToken');
  try {
    const res = await fetch(`${API_BASE}/pomodoro/strict-mode/toggle`, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${userToken}`, 'Content-Type': 'application/json' },
    });
    const data = await res.json();
    if (!res.ok) return;
    strictMode = { ...strictMode, enabled: data.enabled };
    delete pauseState['__strict__'];
    renderStrictModeToggle();
    renderSessions();
    renderStrictVerifySection();
  } catch(e) { console.warn('StrictToggle:', e.message); }
}

function renderStrictVerifySection() {
  const el = document.getElementById('strictVerifySection');
  if (!el) return;
  const state = pauseState['__strict__'];
  if (!state) { el.innerHTML = ''; el.style.display = 'none'; return; }
  el.style.display = 'block';
  let html = '';
  if (state.step === 'email-send') {
    html = `<div style="margin-top:8px;padding:8px;background:#1a1a1a;border-radius:8px;border:1px solid #3f3f46">
      <p style="font-size:0.7rem;color:#71717a;margin-bottom:6px">Necesitas desactivar el modo estricto</p>
      <button class="btn-activate" data-action="strictEmailSend" style="width:100%">${state.loading ? 'Enviando…' : 'Enviar código al email'}</button>
      ${state.err ? `<p class="pause-err">${state.err}</p>` : ''}
    </div>`;
  } else if (state.step === 'email-code') {
    html = `<div style="margin-top:8px;padding:8px;background:#1a1a1a;border-radius:8px;border:1px solid #3f3f46">
      <p style="font-size:0.7rem;color:#71717a;margin-bottom:4px">Código enviado a ${state.sentEmail}</p>
      <div style="display:flex;gap:6px">
        <input class="pause-input" data-action-input="strictVerifyCode" data-autofocus
          type="text" maxlength="6" placeholder="XXXXXX"
          style="flex:1;text-align:center;letter-spacing:4px;font-family:monospace" />
        <button class="btn-activate" data-action="strictVerifyCode">OK</button>
      </div>
      ${state.err ? `<p class="pause-err">${state.err}</p>` : ''}
    </div>`;
  } else if (state.step === 'operations') {
    const op = state.ops[state.opIdx];
    const dots = state.ops.map((_,i) =>
      `<div class="op-dot" style="background:${i<state.opIdx?'#4ade80':i===state.opIdx?'#fff':'#3f3f46'}"></div>`
    ).join('');
    html = `<div style="margin-top:8px;padding:8px;background:#1a1a1a;border-radius:8px;border:1px solid #3f3f46">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px">
        <span style="font-size:0.7rem;color:#71717a">Modo estricto: ${state.opIdx+1}/${state.ops.length}</span>
        <div class="op-dots">${dots}</div>
      </div>
      <p style="font-size:1.1rem;font-weight:700;font-family:monospace;text-align:center;margin:4px 0">${op.q} = ?</p>
      <div style="display:flex;gap:6px">
        <input class="pause-input" data-action-input="strictCheckOp" data-autofocus
          type="number" placeholder="?" style="flex:1;text-align:center" />
        <button class="btn-activate" data-action="strictCheckOp">${state.opIdx+1>=state.ops.length?'Confirmar':'→'}</button>
      </div>
      ${state.err ? `<p class="pause-err">${state.err}</p>` : ''}
    </div>`;
  }
  el.innerHTML = html;
  setTimeout(() => {
    const inp = el.querySelector('[data-autofocus]');
    if (inp) inp.focus();
  }, 30);
}

async function strictEmailSend() {
  pauseState['__strict__'] = { ...pauseState['__strict__'], loading: true };
  renderStrictVerifySection();
  const { userToken } = await chrome.storage.local.get('userToken');
  try {
    const res = await fetch(`${API_BASE}/pomodoro/strict-mode/request-code`, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${userToken}`, 'Content-Type': 'application/json' },
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Error');
    pauseState['__strict__'] = { ...pauseState['__strict__'], step: 'email-code', sentEmail: data.email, loading: false };
  } catch(e) { pauseState['__strict__'] = { ...pauseState['__strict__'], loading: false, err: e.message }; }
  renderStrictVerifySection();
}

async function strictVerifyCodeAction() {
  const inp = document.querySelector('[data-action-input="strictVerifyCode"]');
  const code = inp?.value?.trim();
  if (!code || code.length < 6) return;
  const { userToken } = await chrome.storage.local.get('userToken');
  try {
    const res = await fetch(`${API_BASE}/pomodoro/strict-mode/verify-code`, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${userToken}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ code }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Error');
    await doStrictToggle();
  } catch(e) { pauseState['__strict__'] = { ...pauseState['__strict__'], err: e.message }; renderStrictVerifySection(); }
}

async function strictCheckOp() {
  const inp = document.querySelector('[data-action-input="strictCheckOp"]');
  const val = parseInt(inp?.value?.trim(), 10);
  const state = pauseState['__strict__'];
  const op = state.ops[state.opIdx];
  if (isNaN(val) || val !== op.a) {
    if (state.restart_on_fail) pauseState['__strict__'] = { ...state, opIdx: 0, err: 'Incorrecto. Reiniciando.' };
    else pauseState['__strict__'] = { ...state, err: 'Respuesta incorrecta.' };
    renderStrictVerifySection(); return;
  }
  if (state.opIdx + 1 >= state.ops.length) { await doStrictToggle(); return; }
  pauseState['__strict__'] = { ...state, opIdx: state.opIdx + 1, err: null };
  renderStrictVerifySection();
}

const strictModeToggleEl = document.getElementById('strictModeToggle');
if (strictModeToggleEl) strictModeToggleEl.addEventListener('click', handleStrictToggle);

// ── Add URL ───────────────────────────────────────────────────────────────────
if (addUrlBtn) addUrlBtn.addEventListener('click', async () => {
  const pomodoroId = pomSelect.value;
  if (!pomodoroId || !currentTab?.url) return;

  const urlToAdd = getUrlToAdd(currentTab.url);
  setFeedback('Añadiendo…');
  addUrlBtn.disabled = true;

  try {
    const { userToken } = await chrome.storage.local.get('userToken');
    const res = await fetch(`${API_BASE}/pomodoro/my-pomodoros/${pomodoroId}/add-url`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${userToken}`,
      },
      body: JSON.stringify({ url: urlToAdd, wildcard: wildcardMode }),
    });
    const data = await res.json();

    if (!res.ok) throw new Error(data.error || 'Error');

    setFeedback(data.already ? 'Ya estaba añadida' : '✓ Añadida correctamente', 'success');
    chrome.runtime.sendMessage({ type: 'refresh' });
  } catch (e) {
    setFeedback(e.message || 'Error al añadir', 'error');
  } finally {
    addUrlBtn.disabled = false;
  }
});
