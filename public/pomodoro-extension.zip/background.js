const API_URL = 'https://automatizaciones-production-a376.up.railway.app/pomodoro/status';
const SUPABASE_URL = 'https://wphvmyqsxicyoifrlevt.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_cB3mpag9moVvhekQG6GBWw_ogz_nb9M';

function extractRootDomain(input) {
  let d = input.replace(/^https?:\/\//, '');
  d = d.replace(/^www\./, '');
  d = d.split('/')[0];
  d = d.split(':')[0];
  return d;
}

async function getValidToken() {
  const { userToken, userRefreshToken, userTokenExpiry } = await chrome.storage.local.get([
    'userToken', 'userRefreshToken', 'userTokenExpiry'
  ]);

  if (!userToken) return null;

  // Refresh if expiring in less than 60s
  if (userTokenExpiry && Date.now() >= userTokenExpiry) {
    if (!userRefreshToken) return null;
    try {
      const res = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=refresh_token`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'apikey': SUPABASE_ANON_KEY },
        body: JSON.stringify({ refresh_token: userRefreshToken }),
      });
      const data = await res.json();
      if (!res.ok || !data.access_token) {
        // Token invalid — clear session
        await chrome.storage.local.remove(['userToken', 'userRefreshToken', 'userEmail', 'userTokenExpiry']);
        return null;
      }
      await chrome.storage.local.set({
        userToken: data.access_token,
        userRefreshToken: data.refresh_token,
        userTokenExpiry: Date.now() + (data.expires_in - 60) * 1000,
      });
      return data.access_token;
    } catch {
      return null;
    }
  }

  return userToken;
}

async function updateBlockRules(active, blocked_urls) {
  const existing = await chrome.declarativeNetRequest.getDynamicRules();
  const removeRuleIds = existing.map(r => r.id);

  if (!active || !blocked_urls || blocked_urls.length === 0) {
    await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds });
    return;
  }

  const blockedPageUrl = chrome.runtime.getURL('blocked.html');

  const addRules = [];
  let ruleId = 1;
  blocked_urls.forEach((entry) => {
    const url = typeof entry === 'string' ? entry : entry.url;
    const wildcard = typeof entry === 'string' ? true : (entry.wildcard ?? true);

    if (wildcard) {
      const domain = extractRootDomain(url);
      // requestDomains matches the domain AND all its subdomains (Chrome 98+)
      addRules.push({
        id: ruleId++, priority: 1,
        action: { type: 'redirect', redirect: { url: blockedPageUrl } },
        condition: { requestDomains: [domain], resourceTypes: ['main_frame'] },
      });
    } else {
      const clean = url.replace(/^https?:\/\//, '').replace(/^www\./, '');
      addRules.push({
        id: ruleId++, priority: 1,
        action: { type: 'redirect', redirect: { url: blockedPageUrl } },
        condition: { urlFilter: `||${clean}`, resourceTypes: ['main_frame'] },
      });
    }
  });

  await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds, addRules });
}

// Checks if a URL is covered by the blocked_urls list (wildcard-aware)
function isUrlBlocked(url, blockedUrls) {
  if (!blockedUrls || !blockedUrls.length) return false;
  try {
    const hostname = new URL(url).hostname.replace(/^www\./, '');
    return blockedUrls.some(entry => {
      const entryUrl = typeof entry === 'string' ? entry : entry.url;
      const wildcard = typeof entry === 'string' ? true : (entry.wildcard ?? true);
      const domain = extractRootDomain(entryUrl);
      if (wildcard) {
        return hostname === domain || hostname.endsWith('.' + domain);
      } else {
        const clean = entryUrl.replace(/^https?:\/\//, '').replace(/^www\./, '');
        const urlClean = url.replace(/^https?:\/\//, '').replace(/^www\./, '').split('#')[0];
        return urlClean.startsWith(clean);
      }
    });
  } catch { return false; }
}

// Fallback blocker: catches SW-cached refreshes (Cmd+R) and bfcache restores
// that bypass declarativeNetRequest
chrome.webNavigation.onCommitted.addListener(async (details) => {
  if (details.frameId !== 0) return;
  const { active, blocked_urls } = await chrome.storage.local.get(['active', 'blocked_urls']);
  if (!active || !blocked_urls?.length) return;
  if (isUrlBlocked(details.url, blocked_urls)) {
    chrome.tabs.update(details.tabId, { url: chrome.runtime.getURL('blocked.html') });
  }
}, { url: [{ schemes: ['http', 'https'] }] });

async function fetchStatus() {
  try {
    const token = await getValidToken();
    const headers = token ? { 'Authorization': `Bearer ${token}` } : {};

    const res = await fetch(API_URL, { headers });
    if (!res.ok) { console.warn('[Pomodoro] API error:', res.status); return; }
    const data = await res.json();

    const active = data.active || false;
    const blocked_urls = data.blocked_urls || [];
    const ends_at = data.ends_at || null;
    const has_biblioteca = data.has_biblioteca || false;

    await chrome.storage.local.set({ active, blocked_urls, ends_at, has_biblioteca });
    await updateBlockRules(active, blocked_urls);

    // Redirect any already-open tabs that are on blocked URLs
    if (active && blocked_urls.length > 0) {
      try {
        const blockedPageUrl = chrome.runtime.getURL('blocked.html');
        const tabs = await chrome.tabs.query({});
        for (const tab of tabs) {
          if (tab.url && tab.url.startsWith('http') && isUrlBlocked(tab.url, blocked_urls)) {
            chrome.tabs.update(tab.id, { url: blockedPageUrl }).catch(() => {});
          }
        }
      } catch (_) {}
    }
  } catch (e) {
    console.error('[Pomodoro] Error en fetch:', e.message);
  }
}

chrome.alarms.create('poll', { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'poll') fetchStatus();
});

let lastFetch = 0;
chrome.webNavigation.onBeforeNavigate.addListener((details) => {
  if (details.frameId !== 0) return;
  const now = Date.now();
  if (now - lastFetch < 5000) return;
  lastFetch = now;
  fetchStatus();
});

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'refresh') {
    lastFetch = 0;
    fetchStatus();
  }
  if (msg.type === 'setSession') {
    chrome.storage.local.set({
      userToken:        msg.token,
      userRefreshToken: msg.refreshToken,
      userEmail:        msg.email,
      userTokenExpiry:  msg.expiresAt || null,
    }).then(() => { lastFetch = 0; fetchStatus(); });
  }
  if (msg.type === 'clearSession') {
    chrome.storage.local.remove(['userToken', 'userRefreshToken', 'userEmail', 'userTokenExpiry'])
      .then(() => { lastFetch = 0; fetchStatus(); });
  }
});

fetchStatus();
