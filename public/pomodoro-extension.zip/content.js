// Sync Supabase session from the admin page to the extension automatically
function findSupabaseSession() {
  try {
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && (key.startsWith('sb-') || key.includes('supabase')) && key.endsWith('-auth-token')) {
        const raw = localStorage.getItem(key);
        if (!raw) continue;
        const session = JSON.parse(raw);
        if (session?.access_token) return session;
      }
    }
  } catch (_) {}
  return null;
}

function syncSession() {
  try {
    const session = findSupabaseSession();
    if (session) {
      chrome.runtime.sendMessage({
        type: 'setSession',
        token: session.access_token,
        refreshToken: session.refresh_token,
        email: session.user?.email,
        // expires_at is in seconds, convert to ms with 60s margin
        expiresAt: session.expires_at ? session.expires_at * 1000 - 60000 : null,
      });
    } else {
      // No session in localStorage — user logged out
      chrome.runtime.sendMessage({ type: 'clearSession' });
    }
  } catch (_) {
    // Extension context invalidated (reloaded/updated) — ignore
  }
}

// Sync immediately on page load (localStorage already has the persisted session)
syncSession();

// Sync when another tab changes localStorage (cross-tab login/logout)
window.addEventListener('storage', (e) => {
  if (e.key && (e.key.startsWith('sb-') || e.key.includes('supabase'))) {
    try { syncSession(); } catch (_) {}
  }
});

// Forward admin page signals to the extension background
window.addEventListener('pomodoroRefresh', () => {
  try {
    chrome.runtime.sendMessage({ type: 'refresh' });
  } catch (_) {}
});
