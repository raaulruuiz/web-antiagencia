const SUPABASE_URL   = 'https://wphvmyqsxicyoifrlevt.supabase.co';
const SUPABASE_ANON  = 'sb_publishable_cB3mpag9moVvhekQG6GBWw_ogz_nb9M';
const API_BASE       = 'https://automatizaciones-production-a376.up.railway.app';

// ── Elements ──────────────────────────────────────────────────────────────────
const loginView      = document.getElementById('loginView');
const sessionView    = document.getElementById('sessionView');
const emailInput     = document.getElementById('emailInput');
const passInput      = document.getElementById('passwordInput');
const loginBtn       = document.getElementById('loginBtn');
const loginError     = document.getElementById('loginError');
const logoutBtn      = document.getElementById('logoutBtn');
const userEmailEl    = document.getElementById('userEmail');
const pomStatusEl    = document.getElementById('pomStatus');
const countdownEl    = document.getElementById('countdown');
const urlDisplay     = document.getElementById('currentUrlDisplay');
const wildcardToggle = document.getElementById('wildcardToggle');
const wildcardLabel  = document.getElementById('wildcardLabel');
const pomSelect      = document.getElementById('pomodoroSelect');
const addUrlBtn      = document.getElementById('addUrlBtn');
const addFeedback    = document.getElementById('addFeedback');

// ── State ─────────────────────────────────────────────────────────────────────
let wildcardMode = true;   // true = todo el dominio, false = URL exacta
let currentTab   = null;

// ── Helpers ───────────────────────────────────────────────────────────────────
function formatTime(ms) {
  if (ms <= 0) return '00:00';
  const s = Math.floor(ms / 1000);
  return `${Math.floor(s / 60).toString().padStart(2, '0')}:${(s % 60).toString().padStart(2, '0')}`;
}

function extractDomain(url) {
  try {
    return new URL(url).hostname.replace(/^www\./, '');
  } catch { return url; }
}

function getUrlToAdd(fullUrl) {
  if (wildcardMode) return extractDomain(fullUrl);
  try {
    const u = new URL(fullUrl);
    return (u.hostname + u.pathname).replace(/^www\./, '').replace(/\/$/, '');
  } catch { return fullUrl; }
}

function updateWildcardUI() {
  wildcardToggle.classList.toggle('on', wildcardMode);
  wildcardLabel.textContent = wildcardMode ? 'Todo el dominio' : 'URL exacta';
  if (currentTab?.url) {
    urlDisplay.textContent = getUrlToAdd(currentTab.url);
  }
}

function renderStatus({ active, ends_at }) {
  if (active && ends_at) {
    const rem = new Date(ends_at).getTime() - Date.now();
    if (rem > 0) {
      pomStatusEl.textContent = 'Modo trabajo activo';
      pomStatusEl.classList.add('active');
      countdownEl.textContent = formatTime(rem);
      return;
    }
  }
  pomStatusEl.textContent = 'Inactivo';
  pomStatusEl.classList.remove('active');
  countdownEl.textContent = '';
}

function setFeedback(msg, type) {
  addFeedback.textContent = msg;
  addFeedback.className = type || '';
}

// ── Pomodoros list ────────────────────────────────────────────────────────────
async function loadPomodoros(token) {
  try {
    const res = await fetch(`${API_BASE}/pomodoro/my-pomodoros`, {
      headers: { 'Authorization': `Bearer ${token}` },
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Error');

    pomSelect.innerHTML = '';
    if (!data.length) {
      pomSelect.innerHTML = '<option value="">Sin Pomodoros disponibles</option>';
      addUrlBtn.disabled = true;
      return;
    }
    data.forEach(p => {
      const opt = document.createElement('option');
      opt.value = p.id;
      opt.textContent = p.name + (p.is_universal ? ' (Universal)' : ' (Privado)');
      pomSelect.appendChild(opt);
    });
    addUrlBtn.disabled = false;
  } catch {
    pomSelect.innerHTML = '<option value="">Error al cargar</option>';
    addUrlBtn.disabled = true;
  }
}

// ── Show / hide views ─────────────────────────────────────────────────────────
function showSession(email, token) {
  loginView.style.display = 'none';
  sessionView.style.display = 'flex';
  userEmailEl.textContent = email;

  // Get current tab
  chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
    currentTab = tab;
    urlDisplay.textContent = tab?.url ? getUrlToAdd(tab.url) : '—';
  });

  // Status ticker
  chrome.storage.local.get(['active', 'ends_at'], renderStatus);
  setInterval(() => chrome.storage.local.get(['active', 'ends_at'], renderStatus), 1000);

  // Load pomodoros for the dropdown
  loadPomodoros(token);
}

function showLogin() {
  loginView.style.display = 'flex';
  sessionView.style.display = 'none';
}

// ── Init ──────────────────────────────────────────────────────────────────────
chrome.storage.local.get(['userEmail', 'userToken'], ({ userEmail, userToken }) => {
  if (userEmail && userToken) {
    showSession(userEmail, userToken);
  } else {
    showLogin();
  }
});

// ── Login ─────────────────────────────────────────────────────────────────────
loginBtn.addEventListener('click', async () => {
  const email    = emailInput.value.trim();
  const password = passInput.value;
  if (!email || !password) return;

  loginBtn.disabled = true;
  loginBtn.textContent = 'Entrando…';
  loginError.style.display = 'none';

  try {
    const res  = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=password`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'apikey': SUPABASE_ANON },
      body: JSON.stringify({ email, password }),
    });
    const data = await res.json();

    if (!res.ok || !data.access_token) {
      loginError.textContent = data.error_description || 'Credenciales incorrectas';
      loginError.style.display = 'block';
      return;
    }

    await chrome.storage.local.set({
      userToken:        data.access_token,
      userRefreshToken: data.refresh_token,
      userEmail:        data.user.email,
      userTokenExpiry:  Date.now() + (data.expires_in - 60) * 1000,
    });

    chrome.runtime.sendMessage({ type: 'refresh' });
    showSession(data.user.email, data.access_token);
  } catch {
    loginError.textContent = 'Error de conexión';
    loginError.style.display = 'block';
  } finally {
    loginBtn.disabled    = false;
    loginBtn.textContent = 'Entrar';
  }
});

passInput.addEventListener('keydown', e => { if (e.key === 'Enter') loginBtn.click(); });

// ── Logout ────────────────────────────────────────────────────────────────────
logoutBtn.addEventListener('click', async () => {
  await chrome.storage.local.remove(['userToken', 'userRefreshToken', 'userEmail', 'userTokenExpiry']);
  chrome.runtime.sendMessage({ type: 'refresh' });
  showLogin();
  emailInput.value = '';
  passInput.value  = '';
});

// ── Wildcard toggle ───────────────────────────────────────────────────────────
wildcardToggle.addEventListener('click', () => {
  wildcardMode = !wildcardMode;
  updateWildcardUI();
});

// ── Add URL ───────────────────────────────────────────────────────────────────
addUrlBtn.addEventListener('click', async () => {
  const pomodoroId = pomSelect.value;
  if (!pomodoroId || !currentTab?.url) return;

  const urlToAdd = getUrlToAdd(currentTab.url);
  setFeedback('Añadiendo…');
  addUrlBtn.disabled = true;

  try {
    const { userToken } = await chrome.storage.local.get('userToken');
    const res = await fetch(`${API_BASE}/pomodoro/my-pomodoros/${pomodoroId}/add-url`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${userToken}`,
      },
      body: JSON.stringify({ url: urlToAdd, wildcard: wildcardMode }),
    });
    const data = await res.json();

    if (!res.ok) throw new Error(data.error || 'Error');

    setFeedback(data.already ? 'Ya estaba añadida' : '✓ Añadida correctamente', 'success');
    chrome.runtime.sendMessage({ type: 'refresh' });
  } catch (e) {
    setFeedback(e.message || 'Error al añadir', 'error');
  } finally {
    addUrlBtn.disabled = false;
  }
});
