const SUPABASE_URL = 'https://wphvmyqsxicyoifrlevt.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_cB3mpag9moVvhekQG6GBWw_ogz_nb9M';

const loginView   = document.getElementById('loginView');
const sessionView = document.getElementById('sessionView');
const emailInput  = document.getElementById('emailInput');
const passInput   = document.getElementById('passwordInput');
const loginBtn    = document.getElementById('loginBtn');
const loginError  = document.getElementById('loginError');
const logoutBtn   = document.getElementById('logoutBtn');
const userEmailEl = document.getElementById('userEmail');
const pomStatusEl = document.getElementById('pomStatus');
const countdownEl = document.getElementById('countdown');
const urlsEl      = document.getElementById('urls');

function formatTime(ms) {
  if (ms <= 0) return '00:00';
  const s = Math.floor(ms / 1000);
  return `${Math.floor(s / 60).toString().padStart(2, '0')}:${(s % 60).toString().padStart(2, '0')}`;
}

function showSession(email) {
  loginView.style.display = 'none';
  sessionView.style.display = 'flex';
  userEmailEl.textContent = email;
}

function showLogin() {
  loginView.style.display = 'flex';
  sessionView.style.display = 'none';
}

function renderPomodoro({ active, ends_at, blocked_urls }) {
  if (active && ends_at) {
    const remaining = new Date(ends_at).getTime() - Date.now();
    if (remaining > 0) {
      pomStatusEl.textContent = 'Modo trabajo activo';
      pomStatusEl.classList.add('active');
      countdownEl.textContent = formatTime(remaining);
    } else {
      pomStatusEl.textContent = 'Sesion terminada';
      pomStatusEl.classList.remove('active');
      countdownEl.textContent = '';
    }
  } else {
    pomStatusEl.textContent = 'Inactivo';
    pomStatusEl.classList.remove('active');
    countdownEl.textContent = '';
  }
  urlsEl.innerHTML = (blocked_urls || [])
    .map(u => `<span>${typeof u === 'string' ? u : u.url}</span>`)
    .join('');
}

// Init: check stored session
chrome.storage.local.get(['userEmail', 'userToken'], ({ userEmail, userToken }) => {
  if (userEmail && userToken) {
    showSession(userEmail);
    chrome.storage.local.get(['active', 'ends_at', 'blocked_urls'], renderPomodoro);
    setInterval(() => chrome.storage.local.get(['active', 'ends_at', 'blocked_urls'], renderPomodoro), 1000);
  } else {
    showLogin();
  }
});

// Login
loginBtn.addEventListener('click', async () => {
  const email = emailInput.value.trim();
  const password = passInput.value;
  if (!email || !password) return;

  loginBtn.disabled = true;
  loginBtn.textContent = 'Entrando…';
  loginError.style.display = 'none';

  try {
    const res = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=password`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'apikey': SUPABASE_ANON_KEY },
      body: JSON.stringify({ email, password }),
    });
    const data = await res.json();

    if (!res.ok || !data.access_token) {
      loginError.textContent = data.error_description || 'Credenciales incorrectas';
      loginError.style.display = 'block';
      return;
    }

    await chrome.storage.local.set({
      userToken: data.access_token,
      userRefreshToken: data.refresh_token,
      userEmail: data.user.email,
      userTokenExpiry: Date.now() + (data.expires_in - 60) * 1000,
    });

    // Tell background to re-fetch with new token
    chrome.runtime.sendMessage({ type: 'refresh' });

    showSession(data.user.email);
    chrome.storage.local.get(['active', 'ends_at', 'blocked_urls'], renderPomodoro);
    setInterval(() => chrome.storage.local.get(['active', 'ends_at', 'blocked_urls'], renderPomodoro), 1000);
  } catch (e) {
    loginError.textContent = 'Error de conexión';
    loginError.style.display = 'block';
  } finally {
    loginBtn.disabled = false;
    loginBtn.textContent = 'Entrar';
  }
});

passInput.addEventListener('keydown', e => { if (e.key === 'Enter') loginBtn.click(); });

// Logout
logoutBtn.addEventListener('click', async () => {
  await chrome.storage.local.remove(['userToken', 'userRefreshToken', 'userEmail', 'userTokenExpiry']);
  chrome.runtime.sendMessage({ type: 'refresh' });
  showLogin();
  emailInput.value = '';
  passInput.value = '';
});
