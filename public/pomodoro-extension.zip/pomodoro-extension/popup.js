const SUPABASE_URL   = 'https://wphvmyqsxicyoifrlevt.supabase.co';
const SUPABASE_ANON  = 'sb_publishable_cB3mpag9moVvhekQG6GBWw_ogz_nb9M';
const API_BASE       = 'https://automatizaciones-production-a376.up.railway.app';

// ── Elements (lazy getters to avoid null-at-load issues) ─────────────────────
const loginView      = document.getElementById('loginView');
const sessionView    = document.getElementById('sessionView');
const emailInput     = document.getElementById('emailInput');
const passInput      = document.getElementById('passwordInput');
const loginBtn       = document.getElementById('loginBtn');
const loginError     = document.getElementById('loginError');
const logoutBtn      = document.getElementById('logoutBtn');
const wildcardToggle = document.getElementById('wildcardToggle');
const pomSelect      = document.getElementById('pomodoroSelect');
const addUrlBtn      = document.getElementById('addUrlBtn');
// Dynamic elements: queried inline to avoid stale null refs
const $ = id => document.getElementById(id);

// ── State ─────────────────────────────────────────────────────────────────────
let wildcardMode  = true;   // true = todo el dominio, false = URL exacta
let currentTab    = null;
let pomodorosMap  = {};     // id → pomodoro data (blocked_urls, etc.)
let sessions      = [];
let strictMode    = { enabled: false, method: { type: 'none' } };
let pauseState    = {};     // state for strict-mode verification flow
let activeTabName = 'biblioteca'; // 'pomodoro' | 'biblioteca'

// ── JWT helper ────────────────────────────────────────────────────────────────
function decodeJWT(token) {
  try {
    const payload = token.split('.')[1];
    return JSON.parse(atob(payload.replace(/-/g, '+').replace(/_/g, '/')));
  } catch { return null; }
}

function hasBibliotecaAccess(token) {
  const payload = decodeJWT(token);
  if (!payload) return false;
  const role = payload.app_metadata?.role || 'lector';
  const extPages = payload.app_metadata?.ext_pages || [];
  return role === 'admin' || extPages.includes('biblioteca');
}

function hasCSSAccess(token) {
  const payload = decodeJWT(token);
  if (!payload) return false;
  const role = payload.app_metadata?.role || 'lector';
  const extPages = payload.app_metadata?.ext_pages || [];
  return role === 'admin' || extPages.includes('css');
}

// ── Tab switching ─────────────────────────────────────────────────────────────
function switchTab(tab) {
  activeTabName = tab;
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.toggle('active', b.dataset.tab === tab));
  const tabPomodoro   = document.getElementById('tabPomodoro');
  const tabBiblioteca = document.getElementById('tabBiblioteca');
  const tabCSS        = document.getElementById('tabCSS');
  if (tabPomodoro)   tabPomodoro.style.display   = tab === 'pomodoro'   ? 'flex' : 'none';
  if (tabBiblioteca) tabBiblioteca.style.display = tab === 'biblioteca' ? 'flex' : 'none';
  if (tabCSS) {
    tabCSS.style.display = tab === 'css' ? 'flex' : 'none';
    if (tab === 'css' && !cssData) analyzePage();
  }
}

document.querySelector('.tab-bar')?.addEventListener('click', e => {
  const btn = e.target.closest('.tab-btn');
  if (btn && btn.dataset.tab) switchTab(btn.dataset.tab);
});

// ── Helpers ───────────────────────────────────────────────────────────────────
function formatTime(ms) {
  if (ms <= 0) return '00:00';
  const s = Math.floor(ms / 1000);
  return `${Math.floor(s / 60).toString().padStart(2, '0')}:${(s % 60).toString().padStart(2, '0')}`;
}

function extractDomain(url) {
  try {
    return new URL(url).hostname.replace(/^www\./, '');
  } catch { return url; }
}

function getUrlToAdd(fullUrl) {
  if (wildcardMode) return extractDomain(fullUrl);
  try {
    const u = new URL(fullUrl);
    return (u.hostname + u.pathname).replace(/^www\./, '').replace(/\/$/, '');
  } catch { return fullUrl; }
}

function updateWildcardUI() {
  if (wildcardToggle) wildcardToggle.classList.toggle('on', wildcardMode);
  const wildcardLabel = $('wildcardLabel');
  if (wildcardLabel) wildcardLabel.textContent = wildcardMode ? 'Todo el dominio' : 'URL exacta';
  const urlDisplay = $('currentUrlDisplay');
  if (urlDisplay && currentTab?.url) urlDisplay.textContent = getUrlToAdd(currentTab.url);
}

function renderStatus({ active, ends_at }) {
  const pomStatusEl = $('pomStatus');
  const countdownEl = $('countdown');
  if (!pomStatusEl || !countdownEl) return;
  if (active && ends_at) {
    const rem = new Date(ends_at).getTime() - Date.now();
    if (rem > 0) {
      pomStatusEl.textContent = 'Modo trabajo activo';
      pomStatusEl.classList.add('active');
      countdownEl.textContent = formatTime(rem);
      return;
    }
  }
  pomStatusEl.textContent = 'Inactivo';
  pomStatusEl.classList.remove('active');
  countdownEl.textContent = '';
}

function setFeedback(msg, type) {
  const addFeedback = $('addFeedback');
  if (!addFeedback) return;
  addFeedback.textContent = msg;
  addFeedback.className = type || '';
}

// ── Already-added check ───────────────────────────────────────────────────────

function updateAddBtn() {
  if (!pomSelect || !addUrlBtn) return;
  const pomId = pomSelect.value;
  if (!pomId || !currentTab?.url) { addUrlBtn.disabled = true; return; }
  const pom = pomodorosMap[pomId];
  if (!pom) { addUrlBtn.disabled = true; return; }
  const urlToAdd = getUrlToAdd(currentTab.url);
  const alreadyAdded = (pom.blocked_urls || []).some(u => {
    if (u.url === urlToAdd) return true;
    if (u.wildcard && urlToAdd.endsWith('.' + u.url)) return true;
    return false;
  });
  if (alreadyAdded) {
    addUrlBtn.disabled = true;
    addUrlBtn.textContent = 'Ya añadida';
    setFeedback('', '');
  } else {
    addUrlBtn.disabled = false;
    addUrlBtn.textContent = 'Añadir a Pomodoro';
    setFeedback('', '');
  }
}

// ── Math operations (for pause method) ───────────────────────────────────────

function rng(a, b) { return Math.floor(Math.random() * (b - a + 1)) + a; }
function generateOp(d) {
  if (d <= 2) { const a=rng(1,d*10),b=rng(1,d*10); return {q:`${a} + ${b}`,a:a+b}; }
  if (d <= 4) {
    const a=rng(2,9),b=rng(2,9);
    if (Math.random()>.5) return {q:`${a} × ${b}`,a:a*b};
    const n=rng(15,50),s=rng(1,n-1); return {q:`${n} − ${s}`,a:n-s};
  }
  if (d <= 6) { const a=rng(3,9),b=rng(3,9),c=rng(1,15); return {q:`${a} × ${b} + ${c}`,a:a*b+c}; }
  const a=rng(3,9),b=rng(3,9),c=rng(2,9),e=rng(1,10); return {q:`(${a}+${b}) × ${c} − ${e}`,a:(a+b)*c-e};
}
function generateOperations(count, ascending) {
  return Array.from({length:count},(_,i)=>generateOp(ascending?Math.round(1+(9*i)/Math.max(count-1,1)):5));
}

// ── Sessions ──────────────────────────────────────────────────────────────────

async function loadSessions() {
  const { userToken } = await chrome.storage.local.get('userToken');
  if (!userToken) return;
  try {
    const res = await fetch(`${API_BASE}/pomodoro/my-sessions`, {
      headers: { 'Authorization': `Bearer ${userToken}` },
    });
    if (!res.ok) return;
    sessions = await res.json();
    renderSessions();
  } catch(e) { console.warn('[Sessions]', e.message); }
}

async function loadStrictMode() {
  const { userToken } = await chrome.storage.local.get('userToken');
  if (!userToken) return;
  try {
    const res = await fetch(`${API_BASE}/pomodoro/strict-mode`, {
      headers: { 'Authorization': `Bearer ${userToken}` },
    });
    if (!res.ok) return;
    strictMode = await res.json();
    renderStrictModeToggle();
    renderSessions(); // re-render to update pause buttons
  } catch(e) { console.warn('[StrictMode]', e.message); }
}

function renderStrictModeToggle() {
  const el = document.getElementById('strictModeToggle');
  const label = document.getElementById('strictModeLabel');
  if (!el || !label) return;
  el.classList.toggle('on', strictMode.enabled);
  label.textContent = strictMode.enabled ? 'Modo estricto activado' : 'Modo estricto desactivado';
}

function renderSessions() {
  const section    = document.getElementById('sessionsSection');
  const activeList = document.getElementById('activePomList');
  if (!section || !activeList) return;

  section.style.display = sessions.length ? 'block' : 'none';

  activeList.innerHTML = sessions.length
    ? sessions.map(renderPomCard).join('')
    : '<p style="font-size:0.72rem;color:#52525b;padding:4px 0">Sin Pomodoros.</p>';

  // Auto-focus any pause input
  setTimeout(() => {
    const inp = document.querySelector('.pause-input[data-autofocus]');
    if (inp) inp.focus();
  }, 30);
}

function renderPomCard(p) {
  const enabled = p.enabled !== false;
  const isRunning = enabled && p.is_running;
  const cd = p.ends_at ? formatTime(new Date(p.ends_at).getTime() - Date.now()) : null;

  // With strict mode on, you cannot disable an active pomodoro
  const strictLocked = strictMode.enabled && enabled;
  const toggleHtml = `<button class="toggle-btn ${enabled ? 'on' : ''}" ${strictLocked ? 'disabled title="Desactiva el modo estricto primero"' : `data-action="togglePom" data-id="${p.id}" title="${enabled ? 'Desactivar' : 'Activar'}"`}>
    <div class="toggle-thumb"></div>
  </button>`;

  const rightHtml = isRunning && cd ? `<span class="pom-cd" id="cd-${p.id}">${cd}</span>` : '';

  return `<div class="pom-card" id="pom-card-${p.id}" style="${!enabled ? 'opacity:0.5' : ''}">
    <div class="pom-row">
      ${toggleHtml}
      <span class="pom-name" style="flex:1;margin-left:8px">${p.name}</span>
      <div class="pom-row-right">
        ${rightHtml}
        <button class="edit-icon-btn" data-action="openEdit" data-id="${p.id}" title="Editar"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg></button>
      </div>
    </div>
  </div>`;
}

// ── Session actions ───────────────────────────────────────────────────────────

async function togglePom(id) {
  const { userToken } = await chrome.storage.local.get('userToken');
  try {
    const res = await fetch(`${API_BASE}/pomodoro/sessions/${id}/toggle`, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${userToken}`, 'Content-Type': 'application/json' },
    });
    const data = await res.json();
    if (!res.ok) return;
    const p = sessions.find(s => s.id === id);
    if (p) p.enabled = data.enabled;
    renderSessions();
  } catch(e) { console.warn('Toggle:', e.message); }
}

// ── Sessions event delegation ─────────────────────────────────────────────────

const sessionsSectionEl = document.getElementById('sessionsSection');
if (sessionsSectionEl) {
  sessionsSectionEl.addEventListener('click', e => {
    const btn = e.target.closest('[data-action]');
    if (!btn) return;
    const { action, id } = btn.dataset;
    if (action === 'togglePom')              togglePom(id);
    else if (action === 'openEdit')          chrome.tabs.create({ url: `https://antiagencia.es/admin/pomodoro?edit=${id}` });
    else if (action === 'strictVerifyCancel') { delete pauseState['__strict__']; renderStrictVerifySection(); }
    else if (action === 'strictToggle')      handleStrictToggle();
    else if (action === 'strictEmailSend')   strictEmailSend();
    else if (action === 'strictVerifyCode')  strictVerifyCodeAction();
    else if (action === 'strictCheckOp')     strictCheckOp();
  });

  sessionsSectionEl.addEventListener('keydown', e => {
    if (e.key !== 'Enter') return;
    const inp = e.target.closest('[data-action-input]');
    if (!inp) return;
    if (inp.dataset.actionInput === 'strictVerifyCode') strictVerifyCodeAction();
    else if (inp.dataset.actionInput === 'strictCheckOp') strictCheckOp();
  });

  sessionsSectionEl.addEventListener('input', e => {
    const sInp = e.target.closest('[data-action-input="strictVerifyCode"]');
    if (sInp) sInp.value = sInp.value.toUpperCase();
  });
}

// ── Strict verify section event delegation (outside sessionsSection) ──────────

const strictVerifySectionEl = document.getElementById('strictVerifySection');
if (strictVerifySectionEl) {
  strictVerifySectionEl.addEventListener('click', e => {
    const btn = e.target.closest('[data-action]');
    if (!btn) return;
    const { action } = btn.dataset;
    if (action === 'strictVerifyCancel') { delete pauseState['__strict__']; renderStrictVerifySection(); }
    else if (action === 'strictEmailSend')  strictEmailSend();
    else if (action === 'strictVerifyCode') strictVerifyCodeAction();
    else if (action === 'strictCheckOp')    strictCheckOp();
  });
  strictVerifySectionEl.addEventListener('keydown', e => {
    if (e.key !== 'Enter') return;
    const inp = e.target.closest('[data-action-input]');
    if (!inp) return;
    if (inp.dataset.actionInput === 'strictVerifyCode') strictVerifyCodeAction();
    else if (inp.dataset.actionInput === 'strictCheckOp') strictCheckOp();
  });
  strictVerifySectionEl.addEventListener('input', e => {
    const sInp = e.target.closest('[data-action-input="strictVerifyCode"]');
    if (sInp) sInp.value = sInp.value.toUpperCase();
  });
}

// Countdown ticker for sessions
setInterval(() => {
  sessions.forEach(p => {
    if (p.is_running && p.ends_at) {
      const el = document.getElementById(`cd-${p.id}`);
      if (el) el.textContent = formatTime(new Date(p.ends_at).getTime() - Date.now());
    }
  });
}, 1000);

// ── Pomodoros list ────────────────────────────────────────────────────────────
function getValidTokenFromBg() {
  return new Promise(resolve => {
    chrome.runtime.sendMessage({ type: 'getValidToken' }, resp => {
      if (chrome.runtime.lastError) { resolve(null); return; }
      resolve(resp?.token || null);
    });
  });
}

async function loadPomodoros(tokenHint, retry = 2) {
  try {
    // Always use background's refreshed token (handles expiry + auto-refresh)
    const token = await getValidTokenFromBg() || tokenHint;
    if (!token) throw new Error('Sin token');
    const res = await fetch(`${API_BASE}/pomodoro/my-pomodoros`, {
      headers: { 'Authorization': `Bearer ${token}` },
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Error');

    pomodorosMap = {};
    if (!pomSelect || !addUrlBtn) return;
    pomSelect.innerHTML = '';
    if (!data.length) {
      pomSelect.innerHTML = '<option value="">Sin Pomodoros disponibles</option>';
      addUrlBtn.disabled = true;
      return;
    }
    data.forEach(p => {
      pomodorosMap[p.id] = p;
      const opt = document.createElement('option');
      opt.value = p.id;
      opt.textContent = p.name + (p.is_universal ? ' (Universal)' : ' (Privado)');
      pomSelect.appendChild(opt);
    });
    updateAddBtn();
  } catch {
    if (retry > 0) {
      if (pomSelect) pomSelect.innerHTML = '<option value="">Conectando…</option>';
      if (addUrlBtn) addUrlBtn.disabled = true;
      setTimeout(() => loadPomodoros(tokenHint, retry - 1), 4000);
    } else {
      if (pomSelect) pomSelect.innerHTML = '<option value="">Error al cargar</option>';
      if (addUrlBtn) addUrlBtn.disabled = true;
    }
  }
}

if (pomSelect) pomSelect.addEventListener('change', updateAddBtn);

// ── Show / hide views ─────────────────────────────────────────────────────────
function showSession(email, token) {
  loginView.style.display = 'none';
  if (sessionView) sessionView.style.display = 'flex';
  const userEmailEl = $('userEmail');
  if (userEmailEl) userEmailEl.textContent = email;

  // Show/hide tabs based on JWT role
  const hasBib = hasBibliotecaAccess(token);
  const hasCSS = hasCSSAccess(token);
  const bibliotecaTabBtn = $('bibliotecaTabBtn');
  const cssTabBtn = $('cssTabBtn');
  if (bibliotecaTabBtn) bibliotecaTabBtn.style.display = hasBib ? '' : 'none';
  if (cssTabBtn) cssTabBtn.style.display = hasCSS ? '' : 'none';
  // Check for pending area capture (direct mode off)
  chrome.storage.local.get('bibPendingCapture', ({ bibPendingCapture: pending }) => {
    if (pending?.dataUrl && hasBib) {
      chrome.storage.local.remove('bibPendingCapture');
      switchTab('biblioteca');
      showBibPreview(pending.dataUrl, pending.filename);
    } else {
      switchTab(hasBib ? 'biblioteca' : 'pomodoro');
    }
  });

  // Get current tab
  chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
    currentTab = tab;
    const urlDisplay = $('currentUrlDisplay');
    if (urlDisplay) urlDisplay.textContent = tab?.url ? getUrlToAdd(tab.url) : '—';
  });

  // Status ticker
  chrome.storage.local.get(['active', 'ends_at'], renderStatus);
  setInterval(() => chrome.storage.local.get(['active', 'ends_at'], renderStatus), 1000);

  // Load pomodoros for the dropdown
  loadPomodoros(token);

  // Load sessions (Mis Pomodoros section) and auto-refresh every 30s
  loadSessions();
  loadStrictMode();
  setInterval(loadSessions, 30000);
}

function showLogin() {
  loginView.style.display = 'flex';
  sessionView.style.display = 'none';
}

// ── Init ──────────────────────────────────────────────────────────────────────
// Helper: read Supabase session directly from localStorage of the antiagencia.es tab
function readSessionFromTab(tab) {
  return chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: () => {
      try {
        for (let i = 0; i < localStorage.length; i++) {
          const key = localStorage.key(i);
          if (key && (key.startsWith('sb-') || key.includes('supabase')) && key.endsWith('-auth-token')) {
            const raw = localStorage.getItem(key);
            if (!raw) continue;
            const s = JSON.parse(raw);
            if (s?.access_token) return {
              token: s.access_token,
              refreshToken: s.refresh_token,
              email: s.user?.email,
              expiresAt: s.expires_at ? s.expires_at * 1000 - 60000 : null,
            };
          }
        }
      } catch (_) {}
      return null;
    },
  }).then(r => r?.[0]?.result || null).catch(() => null);
}

chrome.storage.local.get(['userEmail', 'userToken'], async ({ userEmail, userToken }) => {
  // Always try the antiagencia.es tab first — avoids stale/expired tokens
  // (MV3 service workers can be killed while Supabase rotates refresh tokens,
  // leaving storage with an invalid token)
  try {
    const tabs = await chrome.tabs.query({ url: '*://antiagencia.es/*' });
    const tab = tabs[0];
    if (tab) {
      const session = await readSessionFromTab(tab);
      if (session) {
        await chrome.storage.local.set({
          userToken:        session.token,
          userRefreshToken: session.refreshToken,
          userEmail:        session.email,
          userTokenExpiry:  session.expiresAt,
        });
        showSession(session.email, session.token);
        return;
      }
    }
  } catch (_) {}

  // Fall back to cached storage (e.g., antiagencia.es tab is not open)
  if (userEmail && userToken) {
    showSession(userEmail, userToken);
    return;
  }

  showLogin();
});

// ── Login ─────────────────────────────────────────────────────────────────────
if (loginBtn) loginBtn.addEventListener('click', async () => {
  const email    = emailInput.value.trim();
  const password = passInput.value;
  if (!email || !password) return;

  loginBtn.disabled = true;
  loginBtn.textContent = 'Entrando…';
  loginError.style.display = 'none';

  try {
    const res  = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=password`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'apikey': SUPABASE_ANON },
      body: JSON.stringify({ email, password }),
    });
    const data = await res.json();

    if (!res.ok || !data.access_token) {
      loginError.textContent = data.error_description || 'Credenciales incorrectas';
      loginError.style.display = 'block';
      return;
    }

    await chrome.storage.local.set({
      userToken:        data.access_token,
      userRefreshToken: data.refresh_token,
      userEmail:        data.user.email,
      userTokenExpiry:  Date.now() + (data.expires_in - 60) * 1000,
    });

    chrome.runtime.sendMessage({ type: 'refresh' });
    showSession(data.user.email, data.access_token);
  } catch {
    loginError.textContent = 'Error de conexión';
    loginError.style.display = 'block';
  } finally {
    loginBtn.disabled    = false;
    loginBtn.textContent = 'Entrar';
  }
});

if (passInput) passInput.addEventListener('keydown', e => { if (e.key === 'Enter') loginBtn?.click(); });

// ── Logout ────────────────────────────────────────────────────────────────────
if (logoutBtn) logoutBtn.addEventListener('click', async () => {
  await chrome.storage.local.remove(['userToken', 'userRefreshToken', 'userEmail', 'userTokenExpiry']);
  chrome.runtime.sendMessage({ type: 'refresh' });
  showLogin();
  emailInput.value = '';
  passInput.value  = '';
});

// ── Wildcard toggle ───────────────────────────────────────────────────────────
if (wildcardToggle) wildcardToggle.addEventListener('click', () => {
  wildcardMode = !wildcardMode;
  updateWildcardUI();
  updateAddBtn();
});

// ── Strict mode toggle ────────────────────────────────────────────────────────

async function handleStrictToggle() {
  if (strictMode.enabled) {
    // Need to verify before disabling
    const type = strictMode.method?.type || 'none';
    if (type === 'none') {
      await doStrictToggle();
    } else if (type === 'email') {
      pauseState['__strict__'] = { step: 'email-send', useStrictEmail: true, isStrictToggle: true };
      renderStrictVerifySection();
    } else if (type === 'operations') {
      const ops = generateOperations(strictMode.method?.count || 5, strictMode.method?.ascending !== false);
      pauseState['__strict__'] = { step: 'operations', ops, opIdx: 0, restart_on_fail: strictMode.method?.restart_on_fail || false, isStrictToggle: true };
      renderStrictVerifySection();
    }
  } else {
    await doStrictToggle();
  }
}

async function doStrictToggle() {
  const { userToken } = await chrome.storage.local.get('userToken');
  try {
    const res = await fetch(`${API_BASE}/pomodoro/strict-mode/toggle`, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${userToken}`, 'Content-Type': 'application/json' },
    });
    const data = await res.json();
    if (!res.ok) return;
    strictMode = { ...strictMode, enabled: data.enabled };
    delete pauseState['__strict__'];
    renderStrictModeToggle();
    renderSessions();
    renderStrictVerifySection();
  } catch(e) { console.warn('StrictToggle:', e.message); }
}

function renderStrictVerifySection() {
  const el = document.getElementById('strictVerifySection');
  if (!el) return;
  const state = pauseState['__strict__'];
  if (!state) { el.innerHTML = ''; el.style.display = 'none'; return; }
  el.style.display = 'block';
  let html = '';
  const cancelLink = `<div style="text-align:center;margin-top:10px"><button data-action="strictVerifyCancel" style="background:none;border:none;color:#52525b;font-size:0.7rem;cursor:pointer;width:auto;padding:0;text-decoration:underline">Cancelar</button></div>`;
  if (state.step === 'email-send') {
    html = `<div style="margin-top:8px;padding:8px;background:#1a1a1a;border-radius:8px;border:1px solid #3f3f46">
      <p style="font-size:0.7rem;color:#71717a;margin-bottom:10px">Necesitas desactivar el modo estricto</p>
      <button class="btn-activate" data-action="strictEmailSend" style="width:100%">${state.loading ? 'Enviando…' : 'Enviar código al email'}</button>
      ${state.err ? `<p class="pause-err">${state.err}</p>` : ''}
      ${cancelLink}
    </div>`;
  } else if (state.step === 'email-code') {
    html = `<div style="margin-top:8px;padding:8px;background:#1a1a1a;border-radius:8px;border:1px solid #3f3f46">
      <p style="font-size:0.7rem;color:#71717a;margin-bottom:10px">Código enviado a ${state.sentEmail}</p>
      <input class="pause-input" data-action-input="strictVerifyCode" data-autofocus
        type="text" maxlength="6" placeholder="XXXXXX"
        style="width:100%;text-align:center;letter-spacing:6px;font-family:monospace;font-size:1rem;margin-bottom:8px" />
      <button class="btn-activate" data-action="strictVerifyCode" style="width:100%">OK</button>
      ${state.err ? `<p class="pause-err">${state.err}</p>` : ''}
      ${cancelLink}
    </div>`;
  } else if (state.step === 'operations') {
    const op = state.ops[state.opIdx];
    const dots = state.ops.map((_,i) =>
      `<div class="op-dot" style="background:${i<state.opIdx?'#4ade80':i===state.opIdx?'#fff':'#3f3f46'}"></div>`
    ).join('');
    html = `<div style="margin-top:8px;padding:8px;background:#1a1a1a;border-radius:8px;border:1px solid #3f3f46">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px">
        <span style="font-size:0.7rem;color:#71717a">Modo estricto: ${state.opIdx+1}/${state.ops.length}</span>
        <div class="op-dots">${dots}</div>
      </div>
      <p style="font-size:1.1rem;font-weight:700;font-family:monospace;text-align:center;margin:4px 0">${op.q} = ?</p>
      <div style="display:flex;gap:6px">
        <input class="pause-input" data-action-input="strictCheckOp" data-autofocus
          type="number" placeholder="?" style="flex:1;text-align:center" />
        <button class="btn-activate" data-action="strictCheckOp">${state.opIdx+1>=state.ops.length?'Confirmar':'→'}</button>
      </div>
      ${state.err ? `<p class="pause-err">${state.err}</p>` : ''}
      ${cancelLink}
    </div>`;
  }
  el.innerHTML = html;
  setTimeout(() => {
    const inp = el.querySelector('[data-autofocus]');
    if (inp) inp.focus();
  }, 30);
}

async function strictEmailSend() {
  pauseState['__strict__'] = { ...pauseState['__strict__'], loading: true };
  renderStrictVerifySection();
  const { userToken } = await chrome.storage.local.get('userToken');
  try {
    const res = await fetch(`${API_BASE}/pomodoro/strict-mode/request-code`, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${userToken}`, 'Content-Type': 'application/json' },
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Error');
    pauseState['__strict__'] = { ...pauseState['__strict__'], step: 'email-code', sentEmail: data.email, loading: false };
  } catch(e) { pauseState['__strict__'] = { ...pauseState['__strict__'], loading: false, err: e.message }; }
  renderStrictVerifySection();
}

async function strictVerifyCodeAction() {
  const inp = document.querySelector('[data-action-input="strictVerifyCode"]');
  const code = inp?.value?.trim();
  if (!code || code.length < 6) return;
  const { userToken } = await chrome.storage.local.get('userToken');
  try {
    const res = await fetch(`${API_BASE}/pomodoro/strict-mode/verify-code`, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${userToken}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ code }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Error');
    await doStrictToggle();
  } catch(e) { pauseState['__strict__'] = { ...pauseState['__strict__'], err: e.message }; renderStrictVerifySection(); }
}

async function strictCheckOp() {
  const inp = document.querySelector('[data-action-input="strictCheckOp"]');
  const val = parseInt(inp?.value?.trim(), 10);
  const state = pauseState['__strict__'];
  const op = state.ops[state.opIdx];
  if (isNaN(val) || val !== op.a) {
    if (state.restart_on_fail) pauseState['__strict__'] = { ...state, opIdx: 0, err: 'Incorrecto. Reiniciando.' };
    else pauseState['__strict__'] = { ...state, err: 'Respuesta incorrecta.' };
    renderStrictVerifySection(); return;
  }
  if (state.opIdx + 1 >= state.ops.length) { await doStrictToggle(); return; }
  pauseState['__strict__'] = { ...state, opIdx: state.opIdx + 1, err: null };
  renderStrictVerifySection();
}

const strictModeToggleEl = document.getElementById('strictModeToggle');
if (strictModeToggleEl) strictModeToggleEl.addEventListener('click', handleStrictToggle);

// ── Add URL ───────────────────────────────────────────────────────────────────
if (addUrlBtn) addUrlBtn.addEventListener('click', async () => {
  const pomodoroId = pomSelect.value;
  if (!pomodoroId || !currentTab?.url) return;

  const urlToAdd = getUrlToAdd(currentTab.url);
  setFeedback('Añadiendo…');
  addUrlBtn.disabled = true;

  try {
    const { userToken } = await chrome.storage.local.get('userToken');
    const res = await fetch(`${API_BASE}/pomodoro/my-pomodoros/${pomodoroId}/add-url`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${userToken}`,
      },
      body: JSON.stringify({ url: urlToAdd, wildcard: wildcardMode }),
    });
    const data = await res.json();

    if (!res.ok) throw new Error(data.error || 'Error');

    setFeedback(data.already ? 'Ya estaba añadida' : '✓ Añadida correctamente', 'success');
    chrome.runtime.sendMessage({ type: 'refresh' });
  } catch (e) {
    setFeedback(e.message || 'Error al añadir', 'error');
  } finally {
    addUrlBtn.disabled = false;
  }
});

// ── Biblioteca ────────────────────────────────────────────────────────────────

let bibDirectMode = true; // default: send directly to biblioteca

function setBibStatus(msg, type) {
  const el = $('bibStatus');
  if (!el) return;
  el.textContent = msg;
  el.className = type || '';
}

function setBibLoading(on) {
  ['bibVisibleBtn', 'bibFullBtn', 'bibAreaBtn', 'bibUploadBtn'].forEach(id => {
    const btn = $(id);
    if (btn) btn.disabled = on;
  });
}

async function bibSendMessage(msg) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(msg, resp => {
      if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
      else if (resp?.ok) resolve(resp);
      else reject(new Error(resp?.error || 'Error'));
    });
  });
}

function bibCheckTab() {
  if (!currentTab?.url?.startsWith('http')) {
    setBibStatus('Navega a una página web primero', 'error');
    return false;
  }
  return true;
}

function showBibPreview(dataUrl, filename) {
  const captureView = $('bibCaptureView');
  const previewView = $('bibPreviewView');
  const img = $('bibPreviewImg');
  if (!previewView || !img) return;
  if (captureView) captureView.style.display = 'none';
  img.src = dataUrl;
  img._pendingDataUrl = dataUrl;
  img._pendingFilename = filename;
  previewView.style.display = 'flex';
}

function hideBibPreview() {
  const captureView = $('bibCaptureView');
  const previewView = $('bibPreviewView');
  if (captureView) captureView.style.display = '';
  if (previewView) previewView.style.display = 'none';
  setBibLoading(false);
  setBibStatus('');
}

async function bibCaptureVisible() {
  if (!bibCheckTab()) return;
  setBibStatus('Capturando…', 'loading');
  setBibLoading(true);
  try {
    if (bibDirectMode) {
      const resp = await bibSendMessage({ type: 'bibCaptureVisible', windowId: currentTab.windowId });
      if (resp.id) chrome.tabs.create({ url: `https://antiagencia.es/admin/biblioteca/${resp.id}` });
      window.close();
    } else {
      const resp = await bibSendMessage({ type: 'bibCaptureVisibleOnly', windowId: currentTab.windowId });
      setBibLoading(false);
      setBibStatus('');
      showBibPreview(resp.dataUrl, `visible_${Date.now()}.png`);
    }
  } catch(e) {
    setBibStatus(e.message || 'Error', 'error');
    setBibLoading(false);
  }
}

async function bibCaptureFullPage() {
  if (!bibCheckTab()) return;
  setBibStatus('Capturando página completa…', 'loading');
  setBibLoading(true);
  try {
    if (bibDirectMode) {
      const resp = await bibSendMessage({ type: 'bibCaptureFullPage', tabId: currentTab.id, windowId: currentTab.windowId });
      if (resp.id) chrome.tabs.create({ url: `https://antiagencia.es/admin/biblioteca/${resp.id}` });
      window.close();
    } else {
      const resp = await bibSendMessage({ type: 'bibCaptureFullPageOnly', tabId: currentTab.id, windowId: currentTab.windowId });
      setBibLoading(false);
      setBibStatus('');
      showBibPreview(resp.dataUrl, `fullpage_${Date.now()}.png`);
    }
  } catch(e) {
    setBibStatus(e.message || 'Error', 'error');
    setBibLoading(false);
  }
}

async function bibCaptureArea() {
  if (!bibCheckTab()) return;
  chrome.runtime.sendMessage({ type: 'bibStartSelection', tabId: currentTab.id });
  window.close();
}

async function bibUpload() {
  const input = $('bibFileInput');
  if (!input) return;
  input.value = '';
  input.click();
}

const bibFileInputEl = document.getElementById('bibFileInput');
if (bibFileInputEl) {
  bibFileInputEl.addEventListener('change', async () => {
    const file = bibFileInputEl.files[0];
    if (!file) return;
    if (!bibDirectMode) {
      const dataUrl = await new Promise((resolve, reject) => {
        const r = new FileReader();
        r.onload = e => resolve(e.target.result);
        r.onerror = () => reject(new Error('Error leyendo archivo'));
        r.readAsDataURL(file);
      });
      showBibPreview(dataUrl, file.name);
      return;
    }
    setBibStatus('Subiendo…', 'loading');
    setBibLoading(true);
    try {
      const resp = await bibSendMessage({ type: 'bibUploadFile', name: file.name, dataUrl: await new Promise((resolve, reject) => {
        const r = new FileReader();
        r.onload = e => resolve(e.target.result);
        r.onerror = () => reject(new Error('Error leyendo archivo'));
        r.readAsDataURL(file);
      })});
      if (resp.id) chrome.tabs.create({ url: `https://antiagencia.es/admin/biblioteca/${resp.id}` });
      window.close();
    } catch(e) {
      setBibStatus(e.message || 'Error', 'error');
    } finally {
      setBibLoading(false);
    }
  });
}

// Direct mode toggle
const bibDirectToggle = $('bibDirectToggle');
if (bibDirectToggle) {
  chrome.storage.local.get('bibDirectMode', ({ bibDirectMode: saved }) => {
    bibDirectMode = saved !== false; // default true
    bibDirectToggle.classList.toggle('on', bibDirectMode);
  });
  bibDirectToggle.addEventListener('click', () => {
    bibDirectMode = !bibDirectMode;
    bibDirectToggle.classList.toggle('on', bibDirectMode);
    chrome.storage.local.set({ bibDirectMode });
  });
}

// Open image viewer: expand the popup itself (always above the page)
$('bibPreviewImg')?.addEventListener('click', () => {
  const img = $('bibPreviewImg');
  if (!img?._pendingDataUrl) return;
  const viewerImg = $('bibViewerImg');
  if (!viewerImg) return;
  viewerImg._pendingDataUrl = img._pendingDataUrl;
  viewerImg._pendingFilename = img._pendingFilename;
  viewerImg.src = img._pendingDataUrl;
  document.documentElement.style.width = '780px';
  document.documentElement.style.height = '580px';
  $('bibViewerView').style.display = 'flex';
});

$('bibViewerCloseBtn')?.addEventListener('click', () => {
  $('bibViewerView').style.display = 'none';
  document.documentElement.style.width = '';
  document.documentElement.style.height = '';
});

$('bibViewerSendBtn')?.addEventListener('click', async () => {
  const viewerImg = $('bibViewerImg');
  if (!viewerImg?._pendingDataUrl) return;
  $('bibViewerSendBtn').disabled = true;
  $('bibViewerSendBtn').textContent = 'Subiendo…';
  try {
    const resp = await bibSendMessage({ type: 'bibUploadFile', name: viewerImg._pendingFilename || `captura_${Date.now()}.png`, dataUrl: viewerImg._pendingDataUrl });
    if (resp.id) chrome.tabs.create({ url: `https://antiagencia.es/admin/biblioteca/${resp.id}` });
    window.close();
  } catch(e) {
    $('bibViewerSendBtn').textContent = 'Error';
    setTimeout(() => { $('bibViewerSendBtn').disabled = false; $('bibViewerSendBtn').textContent = 'Llevar a Biblioteca'; }, 2000);
  }
});

$('bibViewerDlBtn')?.addEventListener('click', () => {
  const viewerImg = $('bibViewerImg');
  if (!viewerImg?._pendingDataUrl) return;
  chrome.downloads.download({ url: viewerImg._pendingDataUrl, filename: viewerImg._pendingFilename || `captura_${Date.now()}.png` }, () => window.close());
});

// Modal buttons
$('bibModalSendBtn')?.addEventListener('click', async () => {
  const img = $('bibPreviewImg');
  if (!img?._pendingDataUrl) return;
  $('bibModalSendBtn').disabled = true;
  try {
    const resp = await bibSendMessage({ type: 'bibUploadFile', name: img._pendingFilename || `captura_${Date.now()}.png`, dataUrl: img._pendingDataUrl });
    if (resp.id) chrome.tabs.create({ url: `https://antiagencia.es/admin/biblioteca/${resp.id}` });
    window.close();
  } catch(e) {
    $('bibModalSendBtn').disabled = false;
    setBibStatus(e.message || 'Error', 'error');
  }
});

$('bibModalDownloadBtn')?.addEventListener('click', () => {
  const img = $('bibPreviewImg');
  if (!img?._pendingDataUrl) return;
  chrome.downloads.download({ url: img._pendingDataUrl, filename: img._pendingFilename || `captura_${Date.now()}.png` }, () => window.close());
});

$('bibModalCancelBtn')?.addEventListener('click', () => {
  chrome.storage.local.remove('bibPendingCapture');
  hideBibPreview();
});

$('bibVisibleBtn')?.addEventListener('click', bibCaptureVisible);
$('bibFullBtn')?.addEventListener('click', bibCaptureFullPage);
$('bibAreaBtn')?.addEventListener('click', bibCaptureArea);
$('bibUploadBtn')?.addEventListener('click', bibUpload);

// ── CSS Inspector ─────────────────────────────────────────────────────────────
let cssData = null;

function switchCSSSubTab(tab) {
  document.querySelectorAll('.css-sub-btn').forEach(b => b.classList.toggle('active', b.dataset.csstab === tab));
  ['overview', 'colors', 'fonts', 'assets'].forEach(t => {
    const el = document.getElementById('css' + t[0].toUpperCase() + t.slice(1));
    if (el) el.style.display = t === tab ? 'flex' : 'none';
  });
}

$('tabCSS')?.addEventListener('click', e => {
  const btn = e.target.closest('.css-sub-btn');
  if (btn?.dataset.csstab) switchCSSSubTab(btn.dataset.csstab);
});

// Runs inside the inspected page — no outer scope references allowed
function extractPageCSSData() {
  function rgbToHex(rgb) {
    const m = rgb.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?\)/);
    if (!m) return null;
    const alpha = m[4] !== undefined ? parseFloat(m[4]) : 1;
    if (alpha === 0) return null;
    const r = parseInt(m[1]), g = parseInt(m[2]), b = parseInt(m[3]);
    return '#' + [r, g, b].map(x => x.toString(16).padStart(2, '0')).join('').toUpperCase();
  }

  const colorMap = {};
  const fontMap = {};
  const colorProps = ['color', 'background-color', 'border-top-color', 'outline-color'];
  const els = [...document.querySelectorAll('*')].slice(0, 2000);

  els.forEach(el => {
    try {
      const s = window.getComputedStyle(el);
      colorProps.forEach(p => {
        const v = s.getPropertyValue(p);
        if (!v || v === 'rgba(0, 0, 0, 0)' || v === 'transparent') return;
        const hex = rgbToHex(v);
        if (hex) colorMap[hex] = (colorMap[hex] || 0) + 1;
      });
      const ff = s.fontFamily;
      if (ff) {
        const name = ff.split(',')[0].trim().replace(/['"]/g, '');
        if (name) fontMap[name] = (fontMap[name] || 0) + 1;
      }
    } catch (_) {}
  });

  const hEl = document.querySelector('h1,h2,h3');
  const headingFont = hEl
    ? window.getComputedStyle(hEl).fontFamily.split(',')[0].trim().replace(/['"]/g, '')
    : null;
  const bodyFont = window.getComputedStyle(document.body).fontFamily.split(',')[0].trim().replace(/['"]/g, '');

  const seenSrcs = new Set();
  const assets = [];
  document.querySelectorAll('img[src]').forEach(img => {
    const src = img.src;
    if (!src || seenSrcs.has(src)) return;
    // Allow SVG data URLs; skip other data: schemes (raster blobs, etc.)
    const isSvgData = src.startsWith('data:image/svg+xml');
    if (src.startsWith('data:') && !isSvgData) return;
    const isSvg = src.includes('.svg') || (img.getAttribute('type') || '').includes('svg') || isSvgData;
    const w = img.naturalWidth || img.offsetWidth;
    const h = img.naturalHeight || img.offsetHeight;
    if (!isSvg && w < 10 && h < 10) return;
    seenSrcs.add(src);
    assets.push(src);
  });
  // Inline <svg> elements — serialize to data URL
  document.querySelectorAll('svg').forEach(svg => {
    try {
      const box = svg.getBoundingClientRect();
      // Use rendered size or fallback to SVG width/height attributes
      const attrW = parseFloat(svg.getAttribute('width') || '0');
      const attrH = parseFloat(svg.getAttribute('height') || '0');
      const w = box.width || attrW;
      const h = box.height || attrH;
      if (w < 16 || h < 16) return; // exclude tiny icons
      const s = new XMLSerializer().serializeToString(svg);
      const dataUrl = 'data:image/svg+xml;base64,' + btoa(unescape(encodeURIComponent(s)));
      if (!seenSrcs.has(dataUrl)) { seenSrcs.add(dataUrl); assets.push(dataUrl); }
    } catch (_) {}
  });

  els.forEach(el => {
    try {
      const bg = window.getComputedStyle(el).backgroundImage;
      if (!bg || bg === 'none' || !bg.includes('url(')) return;
      const ms = bg.match(/url\(["']?([^"')]+)["']?\)/g) || [];
      ms.forEach(u => {
        const match = u.match(/url\(["']?([^"')]+)["']?\)/);
        if (match && match[1] && !match[1].startsWith('data:') && !seenSrcs.has(match[1])) {
          seenSrcs.add(match[1]);
          assets.push(match[1]);
        }
      });
    } catch (_) {}
  });

  let totalRules = 0, sheetsCount = 0, totalBytes = 0;
  try {
    [...document.styleSheets].forEach(sheet => {
      // Solo contar hojas externas (<link rel="stylesheet">), igual que CSS Peeper
      if (sheet.href) sheetsCount++;
      try {
        const rules = [...(sheet.cssRules || [])];
        // Contar solo reglas de estilo reales (no @media, @keyframes, etc.), igual que CSS Peeper
        rules.forEach(r => {
          if (r.type === 1) totalRules++; // CSSStyleRule
          totalBytes += (r.cssText || '').length;
        });
      } catch (_) {}
    });
  } catch (_) {}

  let loadTime = null;
  try {
    const nav = performance.getEntriesByType('navigation')[0];
    // CSS Peeper usa DOMContentLoaded, no loadEventEnd
    if (nav && nav.domContentLoadedEventEnd > 0) {
      loadTime = (nav.domContentLoadedEventEnd / 1000).toFixed(1);
    }
  } catch (_) {}

  return {
    title: document.title,
    url: window.location.href,
    colors: Object.entries(colorMap)
      .map(([hex, count]) => ({ hex, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 80),
    fonts: {
      heading: headingFont,
      body: bodyFont,
      all: Object.entries(fontMap)
        .map(([name, count]) => ({ name, count }))
        .sort((a, b) => b.count - a.count),
    },
    assets: assets.slice(0, 40),
    cssInfo: { rules: totalRules, sheets: sheetsCount, kb: Math.round(totalBytes / 1024), loadTime },
  };
}

async function analyzePage() {
  const status = $('cssStatus');
  if (status) status.textContent = '';
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) throw new Error('No hay pestaña activa');
    if (!tab.url?.startsWith('http')) {
      if (status) status.textContent = 'Navega a una web primero';
      return;
    }
    const [res] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: extractPageCSSData,
    });
    if (!res?.result) throw new Error('Sin resultado');
    cssData = res.result;
    renderCSSData();
    if (status) status.textContent = '';
  } catch (e) {
    if (status) status.textContent = 'Error: ' + e.message;
    console.warn('CSS analyze error:', e.message);
  }
}

function renderCSSData() {
  if (!cssData) return;

  // Overview
  const set = (id, val) => { const e = $(id); if (e) e.textContent = val; };
  set('cssTitle', cssData.title);
  set('cssUrl', cssData.url);
  set('cssHeadingFont', cssData.fonts.heading || cssData.fonts.body || '—');
  set('cssBodyFont', cssData.fonts.body || '—');

  const preview = $('cssColorPreview');
  if (preview) {
    preview.innerHTML = '';
    cssData.colors.slice(0, 9).forEach(c => {
      const s = document.createElement('div');
      s.className = 'css-swatch';
      s.style.background = c.hex;
      s.title = c.hex;
      preview.appendChild(s);
    });
    if (cssData.colors.length > 9) {
      const more = document.createElement('span');
      more.style.cssText = 'font-size:0.68rem;color:#52525b;align-self:center;';
      more.textContent = `+${cssData.colors.length - 9}`;
      preview.appendChild(more);
    }
  }

  set('cssRules', cssData.cssInfo.rules.toLocaleString('es'));
  set('cssSize', cssData.cssInfo.kb + ' KB');
  set('cssSheets', cssData.cssInfo.sheets);
  set('cssLoadTime', cssData.cssInfo.loadTime ? cssData.cssInfo.loadTime + 's' : '—');

  // Colors panel
  set('cssColorCount', cssData.colors.length + ' colores');
  const colorList = $('cssColorList');
  if (colorList) {
    colorList.innerHTML = '';
    cssData.colors.forEach(c => {
      const item = document.createElement('div');
      item.className = 'css-color-item';
      item.innerHTML = `
        <div class="css-color-swatch" style="background:${c.hex}"></div>
        <div class="css-color-meta">
          <div class="css-color-hex">${c.hex}</div>
          <div class="css-color-cnt">${c.count} instancias</div>
        </div>
        <button class="css-copy" data-hex="${c.hex}">Copiar</button>
      `;
      colorList.appendChild(item);
    });
  }

  // Fonts panel
  set('cssFontCount', cssData.fonts.all.length + ' fuentes');
  const fontList = $('cssFontList');
  if (fontList) {
    fontList.innerHTML = '';
    cssData.fonts.all.forEach(f => {
      const item = document.createElement('div');
      item.className = 'css-font-item';
      item.innerHTML = `<span class="css-font-name" style="font-family:'${f.name}',sans-serif">${f.name}</span><span class="css-font-cnt">${f.count} usos</span>`;
      fontList.appendChild(item);
    });
  }

  // Assets panel
  set('cssAssetCount', cssData.assets.length + ' assets');
  const exportBtn = $('cssExportAllBtn');
  if (exportBtn) exportBtn.style.display = cssData.assets.length > 0 ? '' : 'none';
  const assetGrid = $('cssAssetGrid');
  if (assetGrid) {
    assetGrid.innerHTML = '';
    cssData.assets.forEach(src => {
      const item = document.createElement('div');
      item.className = 'css-asset';

      const img = document.createElement('img');
      img.src = src;
      img.alt = '';
      img.loading = 'lazy';
      img.onerror = () => item.remove();

      const dlBtn = document.createElement('button');
      dlBtn.className = 'css-asset-dl';
      dlBtn.title = 'Descargar';
      dlBtn.style.opacity = '0';
      dlBtn.style.pointerEvents = 'none';
      dlBtn.innerHTML = `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>`;
      dlBtn.addEventListener('click', async e => {
        e.stopPropagation();
        const filename = src.split('/').pop().split('?')[0] || 'asset';
        try {
          const resp = await fetch(src);
          const blob = await resp.blob();
          const blobUrl = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = blobUrl;
          a.download = filename;
          a.click();
          setTimeout(() => URL.revokeObjectURL(blobUrl), 2000);
        } catch {
          // fallback: abrir en nueva pestaña
          chrome.tabs.create({ url: src });
        }
      });

      // Filename + size overlay
      const info = document.createElement('div');
      info.className = 'css-asset-info';
      info.style.opacity = '0';
      const fname = document.createElement('div');
      fname.className = 'css-asset-fname';
      if (src.startsWith('data:image/svg+xml')) {
        fname.textContent = 'inline-svg.svg';
      } else {
        fname.textContent = src.split('/').pop().split('?')[0] || 'asset';
      }
      const fsize = document.createElement('div');
      fsize.className = 'css-asset-fsize';
      if (src.startsWith('data:image/svg+xml;base64,')) {
        const bytes = Math.round((src.split(',')[1] || '').length * 3 / 4);
        fsize.textContent = bytes > 1024 ? (bytes / 1024).toFixed(1) + ' KB' : bytes + ' B';
      }
      info.appendChild(fname);
      info.appendChild(fsize);

      item.appendChild(img);
      item.appendChild(dlBtn);
      item.appendChild(info);
      let sizeFetched = false;
      item.addEventListener('mouseenter', () => {
        dlBtn.style.opacity = '1'; dlBtn.style.pointerEvents = 'auto';
        info.style.opacity = '1';
        if (!src.startsWith('data:') && !sizeFetched) {
          sizeFetched = true;
          fetch(src, { method: 'HEAD' }).then(r => {
            const cl = r.headers.get('content-length');
            if (cl) {
              const b = parseInt(cl);
              fsize.textContent = b > 1048576 ? (b/1048576).toFixed(1)+' MB' : (b/1024).toFixed(1)+' KB';
            }
          }).catch(() => {});
        }
      });
      item.addEventListener('mouseleave', () => {
        dlBtn.style.opacity = '0'; dlBtn.style.pointerEvents = 'none';
        info.style.opacity = '0';
      });
      assetGrid.appendChild(item);
    });
  }
}

// ── Export All assets as ZIP (STORE, no compression) ─────────────────────────
async function exportAssetsZip() {
  const btn = $('cssExportAllBtn');
  if (btn) { btn.disabled = true; btn.textContent = 'Descargando…'; }

  function u16(n) { const b = new Uint8Array(2); new DataView(b.buffer).setUint16(0, n, true); return b; }
  function u32(n) { const b = new Uint8Array(4); new DataView(b.buffer).setUint32(0, n, true); return b; }
  function concat(...arrays) {
    const total = arrays.reduce((s, a) => s + a.length, 0);
    const out = new Uint8Array(total); let pos = 0;
    for (const a of arrays) { out.set(a, pos); pos += a.length; }
    return out;
  }
  function crc32(data) {
    const t = [];
    for (let i = 0; i < 256; i++) { let c = i; for (let k = 0; k < 8; k++) c = (c & 1) ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[i] = c; }
    let crc = 0xFFFFFFFF;
    for (const b of data) crc = t[(crc ^ b) & 0xFF] ^ (crc >>> 8);
    return (crc ^ 0xFFFFFFFF) >>> 0;
  }

  const enc = new TextEncoder();
  const files = [];
  const seen = new Set();

  for (const src of (cssData?.assets || [])) {
    try {
      let data, name;
      if (src.startsWith('data:')) {
        const m = src.match(/^data:[^;]+;base64,(.+)/);
        if (!m) continue;
        data = Uint8Array.from(atob(m[1]), c => c.charCodeAt(0));
        name = 'inline_svg_' + (seen.size + 1) + '.svg';
      } else {
        const resp = await fetch(src);
        data = new Uint8Array(await resp.arrayBuffer());
        name = src.split('/').pop().split('?')[0] || ('asset_' + (seen.size + 1));
      }
      // Deduplicate filenames
      let finalName = name; let i = 1;
      while (seen.has(finalName)) { const dot = name.lastIndexOf('.'); finalName = (dot > -1 ? name.slice(0, dot) + '_' + i + name.slice(dot) : name + '_' + i); i++; }
      seen.add(finalName);
      files.push({ name: finalName, data });
    } catch (_) {}
  }

  const localParts = [];
  const centralParts = [];
  let offset = 0;

  for (const { name, data } of files) {
    const nb = enc.encode(name);
    const crc = crc32(data);
    const lfh = concat(
      new Uint8Array([0x50,0x4B,0x03,0x04]), u16(20), u16(0), u16(0),
      u16(0), u16(0), u32(crc), u32(data.length), u32(data.length),
      u16(nb.length), u16(0), nb, data
    );
    centralParts.push(concat(
      new Uint8Array([0x50,0x4B,0x01,0x02]), u16(20), u16(20),
      u16(0), u16(0), u16(0), u16(0), u32(crc),
      u32(data.length), u32(data.length),
      u16(nb.length), u16(0), u16(0), u16(0), u16(0), u32(0), u32(offset), nb
    ));
    localParts.push(lfh);
    offset += lfh.length;
  }

  const cdBytes = concat(...centralParts);
  const eocd = concat(
    new Uint8Array([0x50,0x4B,0x05,0x06]), u16(0), u16(0),
    u16(files.length), u16(files.length),
    u32(cdBytes.length), u32(offset), u16(0)
  );

  const zip = new Blob([...localParts, cdBytes, eocd], { type: 'application/zip' });
  const url = URL.createObjectURL(zip);
  const a = document.createElement('a');
  a.href = url;
  a.download = ((cssData?.title || 'assets').replace(/[^a-z0-9]/gi, '_').slice(0, 40)) + '_assets.zip';
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 3000);

  if (btn) { btn.disabled = false; btn.textContent = 'Export All'; }
}

$('cssExportAllBtn')?.addEventListener('click', exportAssetsZip);

// Copy hex on click (event delegation)
document.addEventListener('click', e => {
  const btn = e.target.closest('.css-copy');
  if (btn?.dataset.hex) {
    navigator.clipboard.writeText(btn.dataset.hex).catch(() => {});
    const orig = btn.textContent;
    btn.textContent = '✓';
    setTimeout(() => { btn.textContent = orig; }, 1200);
  }
});

$('cssAnalyzeBtn')?.addEventListener('click', analyzePage);

// ── Inspect Mode ──────────────────────────────────────────────────────────────

// Must be top-level named functions so chrome.scripting.executeScript can use them as func:

function startInspectMode() {
  // Remove any existing inspector elements first
  ['__css_inspector_panel', '__css_inspector_hl', '__css_inspector_label'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.remove();
  });

  let inspecting = true; // true = hover mode, false = detail mode
  let currentEl = null;

  // ── Helper functions ──────────────────────────────────────────────────────

  function rgbToHex(rgb) {
    if (!rgb) return null;
    const m = rgb.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?\)/);
    if (!m) return null;
    const alpha = m[4] !== undefined ? parseFloat(m[4]) : 1;
    if (alpha === 0) return null;
    const r = parseInt(m[1]), g = parseInt(m[2]), b = parseInt(m[3]);
    return '#' + [r, g, b].map(x => x.toString(16).padStart(2, '0')).join('').toUpperCase();
  }

  function getSelector(el) {
    const tag = el.tagName.toLowerCase();
    const classes = [...el.classList].slice(0, 3).join('.');
    return classes ? `${tag}.${classes}` : tag;
  }

  function fmtWeight(w) {
    const map = { '100': 'Thin (100)', '200': 'Extra Light (200)', '300': 'Light (300)', '400': 'Regular (400)', '500': 'Medium (500)', '600': 'Semi Bold (600)', '700': 'Bold (700)', '800': 'Extra Bold (800)', '900': 'Black (900)' };
    return map[w] || w;
  }

  // ── Create floating panel ─────────────────────────────────────────────────

  const panel = document.createElement('div');
  panel.id = '__css_inspector_panel';
  panel.style.cssText = `
    position: fixed;
    top: 0;
    right: 0;
    width: 320px;
    height: 100vh;
    background: #ffffff;
    border-left: 1px solid #e5e7eb;
    z-index: 2147483646;
    overflow-y: auto;
    font-family: -apple-system, BlinkMacSystemFont, system-ui, sans-serif;
    font-size: 13px;
    color: #111827;
    box-shadow: -4px 0 20px rgba(0,0,0,0.12);
    display: flex;
    flex-direction: column;
  `;

  // ── Create highlight overlay ──────────────────────────────────────────────

  const hl = document.createElement('div');
  hl.id = '__css_inspector_hl';
  hl.style.cssText = `
    position: fixed;
    pointer-events: none;
    border: 2px solid #a855f7;
    background: rgba(168,85,247,0.06);
    z-index: 2147483645;
    transition: all 0.08s;
    display: none;
    box-sizing: border-box;
  `;

  // ── Create label ──────────────────────────────────────────────────────────

  const label = document.createElement('div');
  label.id = '__css_inspector_label';
  label.style.cssText = `
    position: fixed;
    pointer-events: none;
    background: #a855f7;
    color: #fff;
    font-family: monospace;
    font-size: 11px;
    padding: 2px 7px;
    border-radius: 4px;
    z-index: 2147483647;
    white-space: nowrap;
    display: none;
    line-height: 1.6;
  `;

  document.body.appendChild(panel);
  document.body.appendChild(hl);
  document.body.appendChild(label);

  // ── Panel header ──────────────────────────────────────────────────────────

  const header = document.createElement('div');
  header.style.cssText = `
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 12px 14px;
    border-bottom: 1px solid #e5e7eb;
    position: sticky;
    top: 0;
    background: #fff;
    z-index: 10;
    flex-shrink: 0;
  `;

  const backBtn = document.createElement('button');
  backBtn.style.cssText = `
    background: none;
    border: none;
    cursor: pointer;
    font-size: 13px;
    font-weight: 600;
    color: #6366f1;
    padding: 0;
    display: flex;
    align-items: center;
    gap: 4px;
    font-family: inherit;
  `;
  backBtn.innerHTML = `✕ Cerrar`;
  backBtn._mode = 'close';

  const showCodeBtn = document.createElement('button');
  showCodeBtn.style.cssText = `
    background: #6366f1;
    color: #fff;
    border: none;
    border-radius: 6px;
    padding: 5px 11px;
    font-size: 12px;
    font-weight: 500;
    cursor: pointer;
    font-family: inherit;
    display: none;
  `;
  showCodeBtn.textContent = 'Ver código';

  header.appendChild(backBtn);
  header.appendChild(showCodeBtn);
  panel.appendChild(header);

  // ── Content area ──────────────────────────────────────────────────────────

  const contentDiv = document.createElement('div');
  contentDiv.style.cssText = `padding: 14px; flex: 1;`;
  contentDiv.innerHTML = `<p style="color:#9ca3af;font-size:12px;text-align:center;margin-top:40px">Haz clic en un elemento para inspeccionar</p>`;
  panel.appendChild(contentDiv);

  // ── Back button logic ─────────────────────────────────────────────────────

  backBtn.addEventListener('click', () => {
    if (backBtn._mode === 'close') {
      window.__stopInspectMode();
    } else {
      inspecting = true;
      currentEl = null;
      showCodeBtn.style.display = 'none';
      hl.style.display = 'none';
      label.style.display = 'none';
      contentDiv.innerHTML = `<p style="color:#9ca3af;font-size:12px;text-align:center;margin-top:40px">Haz clic en un elemento para inspeccionar</p>`;
      backBtn.innerHTML = `✕ Cerrar`;
      backBtn._mode = 'close';
    }
  });

  // ── Show code button logic ────────────────────────────────────────────────

  showCodeBtn.addEventListener('click', () => {
    if (showCodeBtn._el) showCode(showCodeBtn._el);
  });

  // ── showElementDetails ────────────────────────────────────────────────────

  function showElementDetails(el) {
    const cs = window.getComputedStyle(el);
    const rect = el.getBoundingClientRect();
    const W = Math.round(rect.width);
    const H = Math.round(rect.height);
    const selector = getSelector(el);
    const tagName = el.tagName.charAt(0) + el.tagName.slice(1).toLowerCase();

    showCodeBtn._el = el;
    showCodeBtn.style.display = 'block';
    backBtn.innerHTML = `<span style="font-size:16px">&#8592;</span> Inspector`;
    backBtn._mode = 'back';

    // ── IMAGE element: special layout ────────────────────────────────────────
    if (el.tagName === 'IMG') {
      const src = el.src || '';
      const nw = el.naturalWidth || 0;
      const nh = el.naturalHeight || 0;
      contentDiv.innerHTML = `
        <div style="margin-bottom:14px">
          <div style="font-size:10px;color:#9ca3af;text-transform:uppercase;letter-spacing:0.06em;margin-bottom:2px">Imagen</div>
          <div style="font-family:monospace;font-size:15px;color:#4f46e5;font-weight:600;word-break:break-all">${selector}</div>
        </div>
        <div style="background:#f9fafb;border-radius:8px;overflow:hidden;margin-bottom:14px;display:flex;align-items:center;justify-content:center;min-height:120px">
          <img src="${src}" alt="" style="max-width:100%;max-height:240px;object-fit:contain;display:block" />
        </div>
        <div style="margin-bottom:14px">
          <div style="font-size:11px;font-weight:700;color:#111827;margin-bottom:8px;text-transform:uppercase;letter-spacing:0.05em">Propiedades</div>
          <table style="width:100%;border-collapse:collapse;font-size:12px">
            <tr style="border-bottom:1px solid #f3f4f6"><td style="padding:6px 0;color:#6b7280;width:45%">Tamaño</td><td id="__css_img_fsize" style="padding:6px 0;font-weight:500;font-family:monospace">—</td></tr>
            <tr><td style="padding:6px 0;color:#6b7280">Dimensiones</td><td style="padding:6px 0;font-weight:500;font-family:monospace">${nw && nh ? nw + '×' + nh + ' px' : W + '×' + H + ' px'}</td></tr>
          </table>
        </div>
        <button id="__css_img_dl" style="width:100%;padding:10px;background:#fff;border:1px solid #e5e7eb;border-radius:8px;font-size:13px;font-weight:500;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:8px;color:#374151;font-family:inherit">
          ↓ Descargar imagen
        </button>
      `;
      // Fetch file size lazily
      if (src.startsWith('http') || src.startsWith('/')) {
        fetch(src, { method: 'HEAD' }).then(r => {
          const cl = r.headers.get('content-length');
          const sizeEl = document.getElementById('__css_img_fsize');
          if (cl && sizeEl) {
            const b = parseInt(cl);
            sizeEl.textContent = b > 1048576 ? (b/1048576).toFixed(2)+' MB' : (b/1024).toFixed(2)+' KB';
          }
        }).catch(() => {});
      }
      // Download button
      const dlBtn = document.getElementById('__css_img_dl');
      if (dlBtn) {
        dlBtn.addEventListener('click', e => {
          e.stopPropagation();
          const fname = src.split('/').pop().split('?')[0] || 'image';
          fetch(src).then(r => r.blob()).then(blob => {
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url; a.download = fname; a.click();
            setTimeout(() => URL.revokeObjectURL(url), 2000);
          }).catch(() => { window.open(src, '_blank'); });
        });
      }
      return;
    }

    // ── DEFAULT element layout ────────────────────────────────────────────────
    const pad = ['padding-top', 'padding-right', 'padding-bottom', 'padding-left'].map(p => parseFloat(cs.getPropertyValue(p)) || 0);
    const mar = ['margin-top', 'margin-right', 'margin-bottom', 'margin-left'].map(p => parseFloat(cs.getPropertyValue(p)) || 0);
    const fmtNum = n => n === 0 ? '-' : Math.round(n);
    const bgHex = rgbToHex(cs.getPropertyValue('background-color')) || 'transparent';
    const textHex = rgbToHex(cs.getPropertyValue('color')) || '#000000';
    const fontFamily = cs.fontFamily.split(',')[0].trim().replace(/['"]/g, '');
    const br = parseFloat(cs.borderRadius) || 0;

    contentDiv.innerHTML = `
      <div style="margin-bottom:14px">
        <div style="font-size:10px;color:#9ca3af;text-transform:uppercase;letter-spacing:0.06em;margin-bottom:2px">${tagName}</div>
        <div style="font-family:monospace;font-size:15px;color:#4f46e5;font-weight:600;word-break:break-all">${selector}</div>
      </div>

      <!-- Box model -->
      <div style="background:#f3f4f6;border-radius:10px;padding:14px;margin-bottom:14px">
        <div style="font-size:11px;font-weight:600;color:#374151;margin-bottom:10px;text-transform:uppercase;letter-spacing:0.05em">Modelo de caja</div>
        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;grid-template-rows:auto auto auto;gap:0;text-align:center">
          <div></div><div style="font-size:11px;color:#6b7280;padding:4px 0">${fmtNum(mar[0])}</div><div></div>
          <div style="font-size:11px;color:#6b7280;display:flex;align-items:center;justify-content:center;padding:4px 0">${fmtNum(mar[3])}</div>
          <div style="background:#e0e7ff;border-radius:6px;padding:10px 6px;display:flex;align-items:center;justify-content:center;flex-direction:column;gap:4px;margin:2px">
            <div style="font-size:10px;color:#818cf8">${fmtNum(pad[0])}</div>
            <div style="display:flex;align-items:center;gap:6px">
              <span style="font-size:10px;color:#818cf8">${fmtNum(pad[3])}</span>
              <div style="background:#fff;border-radius:4px;padding:5px 10px;font-size:11px;font-weight:700;color:#111827;white-space:nowrap">${W} × ${H}</div>
              <span style="font-size:10px;color:#818cf8">${fmtNum(pad[1])}</span>
            </div>
            <div style="font-size:10px;color:#818cf8">${fmtNum(pad[2])}</div>
          </div>
          <div style="font-size:11px;color:#6b7280;display:flex;align-items:center;justify-content:center;padding:4px 0">${fmtNum(mar[1])}</div>
          <div></div><div style="font-size:11px;color:#6b7280;padding:4px 0">${fmtNum(mar[2])}</div><div></div>
        </div>
      </div>

      <!-- Text properties -->
      <div style="margin-bottom:14px">
        <div style="font-size:11px;font-weight:700;color:#111827;margin-bottom:8px;text-transform:uppercase;letter-spacing:0.05em">Texto</div>
        <table style="width:100%;border-collapse:collapse;font-size:12px">
          <tr style="border-bottom:1px solid #f3f4f6"><td style="padding:5px 0;color:#6b7280;width:45%">Fuente</td><td style="padding:5px 0;font-weight:500;font-family:monospace;word-break:break-all">${fontFamily}</td></tr>
          <tr style="border-bottom:1px solid #f3f4f6"><td style="padding:5px 0;color:#6b7280">Tamaño</td><td style="padding:5px 0;font-weight:500;font-family:monospace">${cs.fontSize}</td></tr>
          <tr style="border-bottom:1px solid #f3f4f6"><td style="padding:5px 0;color:#6b7280">Interlineado</td><td style="padding:5px 0;font-weight:500;font-family:monospace">${cs.lineHeight}</td></tr>
          <tr style="border-bottom:1px solid #f3f4f6"><td style="padding:5px 0;color:#6b7280">Peso</td><td style="padding:5px 0;font-weight:500">${fmtWeight(cs.fontWeight)}</td></tr>
          <tr style="border-bottom:1px solid #f3f4f6"><td style="padding:5px 0;color:#6b7280">Espaciado</td><td style="padding:5px 0;font-weight:500;font-family:monospace">${cs.letterSpacing}</td></tr>
          <tr><td style="padding:5px 0;color:#6b7280">Color texto</td><td style="padding:5px 0;display:flex;align-items:center;gap:6px"><span style="display:inline-block;width:14px;height:14px;background:${textHex};border-radius:3px;border:1px solid rgba(0,0,0,0.1);flex-shrink:0"></span><span style="font-family:monospace;font-weight:500">${textHex}</span></td></tr>
        </table>
      </div>

      <!-- Colors -->
      <div style="margin-bottom:14px">
        <div style="font-size:11px;font-weight:700;color:#111827;margin-bottom:8px;text-transform:uppercase;letter-spacing:0.05em">Colores</div>
        <div style="display:flex;flex-direction:column;gap:6px">
          <div style="background:${bgHex === 'transparent' ? '#f9fafb' : bgHex};border-radius:8px;padding:10px 12px;border:1px solid rgba(0,0,0,0.06);display:flex;align-items:center;justify-content:space-between">
            <div>
              <div style="font-size:10px;color:${bgHex === 'transparent' || bgHex.toUpperCase() === '#FFFFFF' || bgHex.toUpperCase() === '#F9FAFB' ? '#9ca3af' : 'rgba(255,255,255,0.75)'};text-transform:uppercase;letter-spacing:0.05em;margin-bottom:1px">Fondo</div>
              <div style="font-family:monospace;font-size:12px;font-weight:600;color:${bgHex === 'transparent' || bgHex.toUpperCase() === '#FFFFFF' || bgHex.toUpperCase() === '#F9FAFB' ? '#374151' : '#fff'}">${bgHex}</div>
            </div>
            <button class="__css_color_copy" data-hex="${bgHex}" style="background:rgba(255,255,255,0.15);border:none;border-radius:5px;padding:4px 8px;font-size:11px;cursor:pointer;color:${bgHex === 'transparent' || bgHex.toUpperCase() === '#FFFFFF' || bgHex.toUpperCase() === '#F9FAFB' ? '#6b7280' : '#fff'};font-family:monospace;flex-shrink:0">⎘</button>
          </div>
          <div style="background:#fff;border-radius:8px;padding:10px 12px;border:1px solid #e5e7eb;display:flex;align-items:center;justify-content:space-between">
            <div>
              <div style="font-size:10px;color:#9ca3af;text-transform:uppercase;letter-spacing:0.05em;margin-bottom:4px">Texto</div>
              <div style="display:flex;align-items:center;gap:6px"><span style="display:inline-block;width:14px;height:14px;background:${textHex};border-radius:3px;border:1px solid rgba(0,0,0,0.1);flex-shrink:0"></span><span style="font-family:monospace;font-size:12px;font-weight:600;color:#374151">${textHex}</span></div>
            </div>
            <button class="__css_color_copy" data-hex="${textHex}" style="background:#f3f4f6;border:none;border-radius:5px;padding:4px 8px;font-size:11px;cursor:pointer;color:#6b7280;font-family:monospace;flex-shrink:0">⎘</button>
          </div>
        </div>
      </div>

      <!-- Element properties -->
      <div style="margin-bottom:14px">
        <div style="font-size:11px;font-weight:700;color:#111827;margin-bottom:8px;text-transform:uppercase;letter-spacing:0.05em">Elemento</div>
        <table style="width:100%;border-collapse:collapse;font-size:12px">
          <tr style="border-bottom:1px solid #f3f4f6"><td style="padding:5px 0;color:#6b7280;width:45%">Ancho</td><td style="padding:5px 0;font-weight:500;font-family:monospace">${cs.width}</td></tr>
          <tr style="border-bottom:${br > 0 ? '1px solid #f3f4f6' : 'none'}"><td style="padding:5px 0;color:#6b7280">Alto</td><td style="padding:5px 0;font-weight:500;font-family:monospace">${cs.height}</td></tr>
          ${br > 0 ? `<tr><td style="padding:5px 0;color:#6b7280">Radio de borde</td><td style="padding:5px 0;font-weight:500;font-family:monospace">${cs.borderRadius}</td></tr>` : ''}
        </table>
      </div>
    `;
    // Copy buttons
    contentDiv.querySelectorAll('.__css_color_copy').forEach(btn => {
      btn.addEventListener('click', e => {
        e.stopPropagation();
        navigator.clipboard.writeText(btn.dataset.hex).catch(() => {});
        const orig = btn.textContent;
        btn.textContent = '✓';
        setTimeout(() => { btn.textContent = orig; }, 1200);
      });
    });
  }

  // ── showCode ──────────────────────────────────────────────────────────────

  function showCode(el) {
    const existing = document.getElementById('__css_inspector_code_overlay');
    if (existing) existing.remove();

    const cs = window.getComputedStyle(el);

    // HTML
    const rawHtml = el.outerHTML.slice(0, 3000)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');

    // CSS props
    const cssProps = [
      'display', 'position', 'width', 'height', 'min-width', 'max-width', 'min-height', 'max-height',
      'margin', 'margin-top', 'margin-right', 'margin-bottom', 'margin-left',
      'padding', 'padding-top', 'padding-right', 'padding-bottom', 'padding-left',
      'background', 'background-color', 'color',
      'font-family', 'font-size', 'font-weight', 'line-height', 'letter-spacing',
      'border', 'border-radius',
      'flex', 'flex-direction', 'flex-wrap', 'align-items', 'justify-content',
      'grid', 'grid-template-columns', 'grid-template-rows', 'gap',
      'overflow', 'overflow-x', 'overflow-y',
      'opacity', 'transform', 'box-shadow', 'z-index'
    ];

    const skipValues = new Set(['auto', 'none', 'normal', '0px', 'initial', 'unset', 'inherit', '', 'rgba(0, 0, 0, 0)', 'transparent', 'visible', 'static', 'baseline', 'nowrap', 'start', 'stretch', 'inline', 'separate', '0', 'medium', 'currentcolor']);

    const cssLines = cssProps.map(prop => {
      const val = cs.getPropertyValue(prop);
      if (!val || skipValues.has(val.trim())) return null;
      return `  ${prop}: ${val};`;
    }).filter(Boolean);

    const overlay = document.createElement('div');
    overlay.id = '__css_inspector_code_overlay';
    overlay.style.cssText = `
      position: fixed;
      inset: 0;
      background: rgba(0,0,0,0.7);
      z-index: 2147483647;
      display: flex;
      align-items: center;
      justify-content: center;
      font-family: monospace;
      backdrop-filter: blur(3px);
    `;

    const box = document.createElement('div');
    box.style.cssText = `
      background: #1e1e2e;
      border-radius: 12px;
      width: 90vw;
      max-width: 800px;
      max-height: 85vh;
      overflow: hidden;
      display: flex;
      flex-direction: column;
      box-shadow: 0 25px 60px rgba(0,0,0,0.5);
    `;

    const boxHeader = document.createElement('div');
    boxHeader.style.cssText = `
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 12px 16px;
      border-bottom: 1px solid #313244;
      flex-shrink: 0;
    `;
    boxHeader.innerHTML = `<span style="color:#cdd6f4;font-size:13px;font-weight:600;font-family:system-ui,sans-serif">Código fuente</span>`;

    const closeBtn = document.createElement('button');
    closeBtn.style.cssText = `
      background: none;
      border: none;
      color: #6c7086;
      font-size: 18px;
      cursor: pointer;
      padding: 0 4px;
      line-height: 1;
      font-family: monospace;
    `;
    closeBtn.textContent = '✕';
    closeBtn.addEventListener('click', () => overlay.remove());
    boxHeader.appendChild(closeBtn);

    const scrollArea = document.createElement('div');
    scrollArea.style.cssText = `overflow-y: auto; padding: 16px; flex: 1;`;

    scrollArea.innerHTML = `
      <div style="margin-bottom:16px">
        <div style="font-size:11px;color:#89b4fa;text-transform:uppercase;letter-spacing:0.08em;margin-bottom:8px;font-family:system-ui,sans-serif">HTML</div>
        <pre style="margin:0;color:#cdd6f4;font-size:12px;line-height:1.6;white-space:pre-wrap;word-break:break-all">${rawHtml}</pre>
      </div>
      <div>
        <div style="font-size:11px;color:#a6e3a1;text-transform:uppercase;letter-spacing:0.08em;margin-bottom:8px;font-family:system-ui,sans-serif">CSS (calculado)</div>
        <pre style="margin:0;color:#cdd6f4;font-size:12px;line-height:1.6">${cssLines.join('\n') || '/* sin estilos relevantes */'}</pre>
      </div>
    `;

    box.appendChild(boxHeader);
    box.appendChild(scrollArea);
    overlay.appendChild(box);
    document.body.appendChild(overlay);

    // Close on backdrop click
    overlay.addEventListener('click', e => {
      if (e.target === overlay) overlay.remove();
    });
  }

  // ── Event handlers ────────────────────────────────────────────────────────

  function onMouseOver(e) {
    if (panel.contains(e.target)) return;
    const codeOverlay = document.getElementById('__css_inspector_code_overlay');
    if (codeOverlay) return;
    if (!inspecting) return;

    const rect = e.target.getBoundingClientRect();
    hl.style.display = 'block';
    hl.style.top = rect.top + 'px';
    hl.style.left = rect.left + 'px';
    hl.style.width = rect.width + 'px';
    hl.style.height = rect.height + 'px';

    label.style.display = 'block';
    label.textContent = getSelector(e.target);
    // Position label near top-left of element, but keep within viewport
    let labelTop = rect.top - 22;
    if (labelTop < 0) labelTop = rect.top + 2;
    label.style.top = labelTop + 'px';
    label.style.left = Math.max(0, rect.left) + 'px';
  }

  function onClick(e) {
    if (panel.contains(e.target)) return;
    // Allow clicks inside the code overlay to work normally
    const codeOverlay = document.getElementById('__css_inspector_code_overlay');
    if (codeOverlay && codeOverlay.contains(e.target)) return;
    e.preventDefault();
    e.stopPropagation();

    inspecting = false;
    currentEl = e.target;

    hl.style.display = 'none';
    label.style.display = 'none';

    showElementDetails(e.target);
  }

  document.addEventListener('mouseover', onMouseOver, true);
  document.addEventListener('click', onClick, true);

  // ── Cleanup ───────────────────────────────────────────────────────────────

  window.__stopInspectMode = function() {
    ['__css_inspector_panel', '__css_inspector_hl', '__css_inspector_label', '__css_inspector_code_overlay'].forEach(id => {
      const el = document.getElementById(id);
      if (el) el.remove();
    });
    document.removeEventListener('mouseover', onMouseOver, true);
    document.removeEventListener('click', onClick, true);
    delete window.__stopInspectMode;
  };
}

function stopInspectMode() {
  if (typeof window.__stopInspectMode === 'function') window.__stopInspectMode();
}

// ── Inspect Mode toggle handler ───────────────────────────────────────────────

let inspectModeActive = false;
const cssInspectToggleBtn = document.getElementById('cssInspectToggle');
if (cssInspectToggleBtn) {
  cssInspectToggleBtn.addEventListener('click', async () => {
    inspectModeActive = !inspectModeActive;
    cssInspectToggleBtn.classList.toggle('on', inspectModeActive);

    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id || !tab.url?.startsWith('http')) {
      inspectModeActive = false;
      cssInspectToggleBtn.classList.remove('on');
      return;
    }

    if (inspectModeActive) {
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: startInspectMode });
    } else {
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: stopInspectMode });
    }
  });
}
