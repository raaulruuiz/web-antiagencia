const SUPABASE_URL   = 'https://wphvmyqsxicyoifrlevt.supabase.co';
const SUPABASE_ANON  = 'sb_publishable_cB3mpag9moVvhekQG6GBWw_ogz_nb9M';
const API_BASE       = 'https://automatizaciones-production-a376.up.railway.app';

// ── Elements ──────────────────────────────────────────────────────────────────
const loginView      = document.getElementById('loginView');
const sessionView    = document.getElementById('sessionView');
const emailInput     = document.getElementById('emailInput');
const passInput      = document.getElementById('passwordInput');
const loginBtn       = document.getElementById('loginBtn');
const loginError     = document.getElementById('loginError');
const logoutBtn      = document.getElementById('logoutBtn');
const userEmailEl    = document.getElementById('userEmail');
const pomStatusEl    = document.getElementById('pomStatus');
const countdownEl    = document.getElementById('countdown');
const urlDisplay     = document.getElementById('currentUrlDisplay');
const wildcardToggle = document.getElementById('wildcardToggle');
const wildcardLabel  = document.getElementById('wildcardLabel');
const pomSelect      = document.getElementById('pomodoroSelect');
const addUrlBtn      = document.getElementById('addUrlBtn');
const addFeedback    = document.getElementById('addFeedback');

// ── State ─────────────────────────────────────────────────────────────────────
let wildcardMode = true;   // true = todo el dominio, false = URL exacta
let currentTab   = null;
let pomodorosMap = {};     // id → pomodoro data (blocked_urls, etc.)
let sessions     = [];
let pauseState   = {};
let inactiveOpen = false;
let strictMode = { enabled: false, method: { type: 'none' } };

// ── Helpers ───────────────────────────────────────────────────────────────────
function formatTime(ms) {
  if (ms <= 0) return '00:00';
  const s = Math.floor(ms / 1000);
  return `${Math.floor(s / 60).toString().padStart(2, '0')}:${(s % 60).toString().padStart(2, '0')}`;
}

function extractDomain(url) {
  try {
    return new URL(url).hostname.replace(/^www\./, '');
  } catch { return url; }
}

function getUrlToAdd(fullUrl) {
  if (wildcardMode) return extractDomain(fullUrl);
  try {
    const u = new URL(fullUrl);
    return (u.hostname + u.pathname).replace(/^www\./, '').replace(/\/$/, '');
  } catch { return fullUrl; }
}

function updateWildcardUI() {
  wildcardToggle.classList.toggle('on', wildcardMode);
  wildcardLabel.textContent = wildcardMode ? 'Todo el dominio' : 'URL exacta';
  if (currentTab?.url) {
    urlDisplay.textContent = getUrlToAdd(currentTab.url);
  }
}

function renderStatus({ active, ends_at }) {
  if (active && ends_at) {
    const rem = new Date(ends_at).getTime() - Date.now();
    if (rem > 0) {
      pomStatusEl.textContent = 'Modo trabajo activo';
      pomStatusEl.classList.add('active');
      countdownEl.textContent = formatTime(rem);
      return;
    }
  }
  pomStatusEl.textContent = 'Inactivo';
  pomStatusEl.classList.remove('active');
  countdownEl.textContent = '';
}

function setFeedback(msg, type) {
  addFeedback.textContent = msg;
  addFeedback.className = type || '';
}

// ── Already-added check ───────────────────────────────────────────────────────

function updateAddBtn() {
  const pomId = pomSelect.value;
  if (!pomId || !currentTab?.url) { addUrlBtn.disabled = true; return; }
  const pom = pomodorosMap[pomId];
  if (!pom) { addUrlBtn.disabled = true; return; }
  const urlToAdd = getUrlToAdd(currentTab.url);
  const alreadyAdded = (pom.blocked_urls || []).some(u => {
    if (u.url === urlToAdd) return true;
    // Si la entrada es wildcard, también cubre subdominios
    if (u.wildcard && urlToAdd.endsWith('.' + u.url)) return true;
    return false;
  });
  if (alreadyAdded) {
    addUrlBtn.disabled = true;
    addUrlBtn.textContent = 'Ya añadida';
    setFeedback('', '');
  } else {
    addUrlBtn.disabled = false;
    addUrlBtn.textContent = 'Añadir a Pomodoro';
    setFeedback('', '');
  }
}

// ── Math operations (for pause method) ───────────────────────────────────────

function rng(a, b) { return Math.floor(Math.random() * (b - a + 1)) + a; }
function generateOp(d) {
  if (d <= 2) { const a=rng(1,d*10),b=rng(1,d*10); return {q:`${a} + ${b}`,a:a+b}; }
  if (d <= 4) {
    const a=rng(2,9),b=rng(2,9);
    if (Math.random()>.5) return {q:`${a} × ${b}`,a:a*b};
    const n=rng(15,50),s=rng(1,n-1); return {q:`${n} − ${s}`,a:n-s};
  }
  if (d <= 6) { const a=rng(3,9),b=rng(3,9),c=rng(1,15); return {q:`${a} × ${b} + ${c}`,a:a*b+c}; }
  const a=rng(3,9),b=rng(3,9),c=rng(2,9),e=rng(1,10); return {q:`(${a}+${b}) × ${c} − ${e}`,a:(a+b)*c-e};
}
function generateOperations(count, ascending) {
  return Array.from({length:count},(_,i)=>generateOp(ascending?Math.round(1+(9*i)/Math.max(count-1,1)):5));
}

// ── Sessions ──────────────────────────────────────────────────────────────────

async function loadSessions() {
  const { userToken } = await chrome.storage.local.get('userToken');
  if (!userToken) return;
  try {
    const res = await fetch(`${API_BASE}/pomodoro/my-sessions`, {
      headers: { 'Authorization': `Bearer ${userToken}` },
    });
    if (!res.ok) return;
    sessions = await res.json();
    renderSessions();
  } catch(e) { console.warn('[Sessions]', e.message); }
}

async function loadStrictMode() {
  const { userToken } = await chrome.storage.local.get('userToken');
  if (!userToken) return;
  try {
    const res = await fetch(`${API_BASE}/pomodoro/strict-mode`, {
      headers: { 'Authorization': `Bearer ${userToken}` },
    });
    if (!res.ok) return;
    strictMode = await res.json();
    renderStrictModeToggle();
    renderSessions(); // re-render to update pause buttons
  } catch(e) { console.warn('[StrictMode]', e.message); }
}

function renderStrictModeToggle() {
  const el = document.getElementById('strictModeToggle');
  const label = document.getElementById('strictModeLabel');
  if (!el || !label) return;
  el.classList.toggle('on', strictMode.enabled);
  label.textContent = strictMode.enabled ? 'Modo estricto activado' : 'Modo estricto desactivado';
}

function renderSessions() {
  const enabled  = sessions.filter(s => s.enabled);
  const disabled = sessions.filter(s => !s.enabled);

  const section      = document.getElementById('sessionsSection');
  const activeList   = document.getElementById('activePomList');
  const inactiveWrap = document.getElementById('inactiveWrap');
  const inactiveList = document.getElementById('inactivePomList');
  const inactiveCountEl = document.getElementById('inactiveCount');

  if (!section) return;
  section.style.display = (enabled.length || disabled.length) ? 'block' : 'none';

  activeList.innerHTML = enabled.length
    ? enabled.map(renderActiveCard).join('')
    : '<p style="font-size:0.72rem;color:#52525b;padding:4px 0">Sin Pomodoros activos.</p>';

  if (disabled.length) {
    inactiveWrap.style.display = 'block';
    inactiveCountEl.textContent = disabled.length;
    inactiveList.innerHTML = disabled.map(p => `
      <div class="pom-inactive-row">
        <span style="font-size:0.75rem;color:#71717a;flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${p.name}</span>
        <button class="btn-activate" data-action="togglePom" data-id="${p.id}">Activar</button>
      </div>`).join('');
    inactiveList.style.display = inactiveOpen ? 'block' : 'none';
    document.getElementById('inactiveToggleBtn').textContent =
      `${inactiveOpen ? '▼' : '▶'} Desactivados (${disabled.length})`;
  } else {
    inactiveWrap.style.display = 'none';
  }

  // Auto-focus any pause input
  setTimeout(() => {
    const inp = document.querySelector('.pause-input[data-autofocus]');
    if (inp) inp.focus();
  }, 30);
}

function renderActiveCard(p) {
  const state = pauseState[p.id] || {};
  const isRunning = p.is_running && !p.is_paused;
  const cd = p.ends_at ? formatTime(new Date(p.ends_at).getTime() - Date.now()) : null;

  let statusHtml = '';
  if (p.is_paused) {
    statusHtml = `<span style="font-size:0.7rem;color:#fbbf24">Pausado</span>
      <button class="btn-resume" data-action="resumePom" data-id="${p.id}">Reanudar</button>`;
  } else if (isRunning) {
    statusHtml = `<span class="pom-cd" id="cd-${p.id}">${cd || '--:--'}</span>
      <button class="btn-pause" data-action="initPause" data-id="${p.id}">Pausar</button>`;
  } else {
    statusHtml = `<span style="font-size:0.7rem;color:#52525b">Fuera de horario</span>`;
  }

  let pauseHtml = '';
  if (state.step === 'confirm') {
    pauseHtml = `<div class="pause-box" style="display:flex;gap:6px">
      <button class="btn-activate" data-action="confirmPause" data-id="${p.id}" style="flex:1">Confirmar pausa</button>
      <button class="btn-resume" data-action="cancelPause" data-id="${p.id}" style="flex:1">Cancelar</button>
    </div>`;
  } else if (state.step === 'email-send') {
    pauseHtml = `<div class="pause-box">
      <button class="btn-activate" data-action="sendEmailCode" data-id="${p.id}" style="width:100%">
        ${state.loading ? 'Enviando…' : 'Enviar código al email'}
      </button>
      ${state.err ? `<p class="pause-err">${state.err}</p>` : ''}
    </div>`;
  } else if (state.step === 'email-code') {
    pauseHtml = `<div class="pause-box">
      <p style="font-size:0.7rem;color:#71717a;margin-bottom:4px">Enviado a ${state.sentEmail}</p>
      <div style="display:flex;gap:6px">
        <input class="pause-input" data-action-input="verifyCode" data-id="${p.id}" data-autofocus
          type="text" maxlength="6" placeholder="XXXXXX"
          style="flex:1;text-align:center;letter-spacing:4px;font-family:monospace" />
        <button class="btn-activate" data-action="verifyCode" data-id="${p.id}">OK</button>
      </div>
      ${state.err ? `<p class="pause-err">${state.err}</p>` : ''}
    </div>`;
  } else if (state.step === 'operations') {
    const op = state.ops[state.opIdx];
    const isLast = state.opIdx + 1 >= state.ops.length;
    const dots = state.ops.map((_,i) =>
      `<div class="op-dot" style="background:${i<state.opIdx?'#4ade80':i===state.opIdx?'#fff':'#3f3f46'}"></div>`
    ).join('');
    pauseHtml = `<div class="pause-box">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px">
        <span style="font-size:0.7rem;color:#71717a">${state.bypass ? 'Desactivar modo estricto · ' : ''}${state.opIdx+1}/${state.ops.length}</span>
        <div class="op-dots">${dots}</div>
      </div>
      <p style="font-size:1.1rem;font-weight:700;font-family:monospace;text-align:center;margin:4px 0">${op.q} = ?</p>
      <div style="display:flex;gap:6px">
        <input class="pause-input" data-action-input="checkOp" data-id="${p.id}" data-autofocus
          type="number" placeholder="?" style="flex:1;text-align:center" />
        <button class="btn-activate" data-action="checkOp" data-id="${p.id}">${isLast?'Pausar':'→'}</button>
      </div>
      ${state.err ? `<p class="pause-err">${state.err}</p>` : ''}
    </div>`;
  } else if (state.step === 'done') {
    pauseHtml = `<p class="pause-ok">Pausado ✓</p>`;
  }

  return `<div class="pom-card" id="pom-card-${p.id}">
    <div class="pom-row">
      <span class="pom-name" style="flex:1">${p.name}</span>
      <div class="pom-row-right">${statusHtml}</div>
    </div>
    ${pauseHtml}
  </div>`;
}

// ── Session actions ───────────────────────────────────────────────────────────

function initPause(id) {
  const p = sessions.find(s => s.id === id);
  if (!p) return;
  // If strict mode ON, use strict mode method instead of pomodoro's own method
  const method = strictMode.enabled ? strictMode.method : (p.pause_method || { type: 'none' });
  const type = method?.type || 'none';
  const bypass = strictMode.enabled; // flag to send to backend
  if (type === 'none') pauseState[id] = { step: 'confirm', bypass };
  else if (type === 'email') pauseState[id] = { step: 'email-send', bypass, useStrictEmail: strictMode.enabled };
  else if (type === 'operations') {
    const ops = generateOperations(method?.count || 5, method?.ascending !== false);
    pauseState[id] = { step: 'operations', ops, opIdx: 0, restart_on_fail: method?.restart_on_fail || false, bypass };
  }
  renderSessions();
}

function cancelPause(id) { delete pauseState[id]; renderSessions(); }

async function disableStrictMode() {
  const { userToken } = await chrome.storage.local.get('userToken');
  try {
    await fetch(`${API_BASE}/pomodoro/strict-mode/toggle`, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${userToken}`, 'Content-Type': 'application/json' },
    });
    strictMode = { ...strictMode, enabled: false };
    renderStrictModeToggle();
  } catch(e) { console.warn('disableStrictMode:', e.message); }
}

async function doApiPause(id, body = {}) {
  const { userToken } = await chrome.storage.local.get('userToken');
  const res = await fetch(`${API_BASE}/pomodoro/sessions/${id}/pause`, {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${userToken}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Error');
}

async function confirmPause(id) {
  try {
    if (pauseState[id]?.bypass) await disableStrictMode();
    await doApiPause(id);
    const p = sessions.find(s => s.id === id);
    if (p) p.is_paused = true;
    pauseState[id] = { step: 'done' };
    renderSessions();
    setTimeout(() => { delete pauseState[id]; loadSessions(); }, 1500);
  } catch(e) { pauseState[id] = { ...pauseState[id], err: e.message }; renderSessions(); }
}

async function sendEmailCode(id) {
  pauseState[id] = { ...pauseState[id], loading: true };
  renderSessions();
  const { userToken } = await chrome.storage.local.get('userToken');
  try {
    const state = pauseState[id] || {};
    const endpoint = state.useStrictEmail
      ? `${API_BASE}/pomodoro/strict-mode/request-code`
      : `${API_BASE}/pomodoro/sessions/${id}/pause-request`;
    const res = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${userToken}`, 'Content-Type': 'application/json' },
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Error');
    pauseState[id] = { ...pauseState[id], step: 'email-code', sentEmail: data.email };
  } catch(e) { pauseState[id] = { step: 'email-send', err: e.message }; }
  renderSessions();
}

async function verifyCode(id) {
  const inp = document.querySelector(`[data-action-input="verifyCode"][data-id="${id}"]`);
  const code = inp?.value?.trim();
  if (!code || code.length < 6) return;
  const state = pauseState[id] || {};
  try {
    if (state.useStrictEmail) {
      const { userToken } = await chrome.storage.local.get('userToken');
      const res = await fetch(`${API_BASE}/pomodoro/strict-mode/verify-code`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${userToken}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ code }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Error');
      // Código verificado: desactivar modo estricto y pausar
      await disableStrictMode();
      await doApiPause(id);
    } else {
      await doApiPause(id, { code });
    }
    const p = sessions.find(s => s.id === id);
    if (p) p.is_paused = true;
    pauseState[id] = { step: 'done' };
    renderSessions();
    setTimeout(() => { delete pauseState[id]; loadSessions(); }, 1500);
  } catch(e) { pauseState[id] = { ...pauseState[id], err: e.message }; renderSessions(); }
}

async function checkOp(id) {
  const inp = document.querySelector(`[data-action-input="checkOp"][data-id="${id}"]`);
  const val = parseInt(inp?.value?.trim(), 10);
  const state = pauseState[id];
  const op = state.ops[state.opIdx];
  if (isNaN(val) || val !== op.a) {
    if (state.restart_on_fail) pauseState[id] = { ...state, opIdx: 0, err: 'Incorrecto. Reiniciando.' };
    else pauseState[id] = { ...state, err: 'Respuesta incorrecta.' };
    renderSessions(); return;
  }
  if (state.opIdx + 1 >= state.ops.length) { await confirmPause(id); return; }
  pauseState[id] = { ...state, opIdx: state.opIdx + 1, err: null };
  renderSessions();
}

async function resumePom(id) {
  const { userToken } = await chrome.storage.local.get('userToken');
  try {
    const res = await fetch(`${API_BASE}/pomodoro/sessions/${id}/resume`, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${userToken}`, 'Content-Type': 'application/json' },
    });
    if (!res.ok) return;
    const p = sessions.find(s => s.id === id);
    if (p) p.is_paused = false;
    delete pauseState[id];
    renderSessions();
  } catch(e) { console.warn('Resume:', e.message); }
}

async function togglePom(id) {
  const { userToken } = await chrome.storage.local.get('userToken');
  try {
    const res = await fetch(`${API_BASE}/pomodoro/sessions/${id}/toggle`, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${userToken}`, 'Content-Type': 'application/json' },
    });
    const data = await res.json();
    if (!res.ok) return;
    const p = sessions.find(s => s.id === id);
    if (p) p.enabled = data.enabled;
    delete pauseState[id];
    renderSessions();
  } catch(e) { console.warn('Toggle:', e.message); }
}

// ── Sessions event delegation ─────────────────────────────────────────────────

document.getElementById('sessionsSection').addEventListener('click', e => {
  const btn = e.target.closest('[data-action]');
  if (!btn) return;
  const { action, id } = btn.dataset;
  if (action === 'initPause')     initPause(id);
  else if (action === 'cancelPause')  cancelPause(id);
  else if (action === 'confirmPause') confirmPause(id);
  else if (action === 'sendEmailCode') sendEmailCode(id);
  else if (action === 'verifyCode')   verifyCode(id);
  else if (action === 'checkOp')      checkOp(id);
  else if (action === 'resumePom')    resumePom(id);
  else if (action === 'togglePom')    togglePom(id);
  else if (action === 'strictToggle') handleStrictToggle();
  else if (action === 'strictEmailSend') strictEmailSend();
  else if (action === 'strictVerifyCode') strictVerifyCodeAction();
  else if (action === 'strictCheckOp') strictCheckOp();
});

document.getElementById('sessionsSection').addEventListener('keydown', e => {
  if (e.key !== 'Enter') return;
  const inp = e.target.closest('[data-action-input]');
  if (!inp) return;
  if (inp.dataset.actionInput === 'verifyCode') verifyCode(inp.dataset.id);
  else if (inp.dataset.actionInput === 'checkOp') checkOp(inp.dataset.id);
  const strictInp = e.target.closest('[data-action-input="strictVerifyCode"], [data-action-input="strictCheckOp"]');
  if (strictInp) {
    if (strictInp.dataset.actionInput === 'strictVerifyCode') strictVerifyCodeAction();
    else if (strictInp.dataset.actionInput === 'strictCheckOp') strictCheckOp();
    return;
  }
});

document.getElementById('sessionsSection').addEventListener('input', e => {
  const inp = e.target.closest('[data-action-input="verifyCode"]');
  if (inp) inp.value = inp.value.toUpperCase();
  const sInp = e.target.closest('[data-action-input="strictVerifyCode"]');
  if (sInp) sInp.value = sInp.value.toUpperCase();
});

document.getElementById('inactiveToggleBtn').addEventListener('click', () => {
  inactiveOpen = !inactiveOpen;
  document.getElementById('inactivePomList').style.display = inactiveOpen ? 'block' : 'none';
  const count = document.getElementById('inactiveCount').textContent;
  document.getElementById('inactiveToggleBtn').textContent =
    `${inactiveOpen ? '▼' : '▶'} Desactivados (${count})`;
});

// Countdown ticker for sessions
setInterval(() => {
  sessions.forEach(p => {
    if (p.is_running && !p.is_paused && p.ends_at) {
      const el = document.getElementById(`cd-${p.id}`);
      if (el) el.textContent = formatTime(new Date(p.ends_at).getTime() - Date.now());
    }
  });
}, 1000);

// ── Pomodoros list ────────────────────────────────────────────────────────────
async function loadPomodoros(token) {
  try {
    const res = await fetch(`${API_BASE}/pomodoro/my-pomodoros`, {
      headers: { 'Authorization': `Bearer ${token}` },
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Error');

    pomodorosMap = {};
    pomSelect.innerHTML = '';
    if (!data.length) {
      pomSelect.innerHTML = '<option value="">Sin Pomodoros disponibles</option>';
      addUrlBtn.disabled = true;
      return;
    }
    data.forEach(p => {
      pomodorosMap[p.id] = p;
      const opt = document.createElement('option');
      opt.value = p.id;
      opt.textContent = p.name + (p.is_universal ? ' (Universal)' : ' (Privado)');
      pomSelect.appendChild(opt);
    });
    updateAddBtn();
  } catch {
    pomSelect.innerHTML = '<option value="">Error al cargar</option>';
    addUrlBtn.disabled = true;
  }
}

pomSelect.addEventListener('change', updateAddBtn);

// ── Show / hide views ─────────────────────────────────────────────────────────
function showSession(email, token) {
  loginView.style.display = 'none';
  sessionView.style.display = 'flex';
  userEmailEl.textContent = email;

  // Get current tab
  chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
    currentTab = tab;
    urlDisplay.textContent = tab?.url ? getUrlToAdd(tab.url) : '—';
  });

  // Status ticker
  chrome.storage.local.get(['active', 'ends_at'], renderStatus);
  setInterval(() => chrome.storage.local.get(['active', 'ends_at'], renderStatus), 1000);

  // Load pomodoros for the dropdown
  loadPomodoros(token);

  // Load sessions (Mis Pomodoros section) and auto-refresh every 30s
  loadSessions();
  loadStrictMode();
  setInterval(loadSessions, 30000);
}

function showLogin() {
  loginView.style.display = 'flex';
  sessionView.style.display = 'none';
}

// ── Init ──────────────────────────────────────────────────────────────────────
chrome.storage.local.get(['userEmail', 'userToken'], ({ userEmail, userToken }) => {
  if (userEmail && userToken) {
    showSession(userEmail, userToken);
  } else {
    showLogin();
  }
});

// ── Login ─────────────────────────────────────────────────────────────────────
loginBtn.addEventListener('click', async () => {
  const email    = emailInput.value.trim();
  const password = passInput.value;
  if (!email || !password) return;

  loginBtn.disabled = true;
  loginBtn.textContent = 'Entrando…';
  loginError.style.display = 'none';

  try {
    const res  = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=password`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'apikey': SUPABASE_ANON },
      body: JSON.stringify({ email, password }),
    });
    const data = await res.json();

    if (!res.ok || !data.access_token) {
      loginError.textContent = data.error_description || 'Credenciales incorrectas';
      loginError.style.display = 'block';
      return;
    }

    await chrome.storage.local.set({
      userToken:        data.access_token,
      userRefreshToken: data.refresh_token,
      userEmail:        data.user.email,
      userTokenExpiry:  Date.now() + (data.expires_in - 60) * 1000,
    });

    chrome.runtime.sendMessage({ type: 'refresh' });
    showSession(data.user.email, data.access_token);
  } catch {
    loginError.textContent = 'Error de conexión';
    loginError.style.display = 'block';
  } finally {
    loginBtn.disabled    = false;
    loginBtn.textContent = 'Entrar';
  }
});

passInput.addEventListener('keydown', e => { if (e.key === 'Enter') loginBtn.click(); });

// ── Logout ────────────────────────────────────────────────────────────────────
logoutBtn.addEventListener('click', async () => {
  await chrome.storage.local.remove(['userToken', 'userRefreshToken', 'userEmail', 'userTokenExpiry']);
  chrome.runtime.sendMessage({ type: 'refresh' });
  showLogin();
  emailInput.value = '';
  passInput.value  = '';
});

// ── Wildcard toggle ───────────────────────────────────────────────────────────
wildcardToggle.addEventListener('click', () => {
  wildcardMode = !wildcardMode;
  updateWildcardUI();
  updateAddBtn();
});

// ── Strict mode toggle ────────────────────────────────────────────────────────

async function handleStrictToggle() {
  if (strictMode.enabled) {
    // Need to verify before disabling
    const type = strictMode.method?.type || 'none';
    if (type === 'none') {
      await doStrictToggle();
    } else if (type === 'email') {
      pauseState['__strict__'] = { step: 'email-send', useStrictEmail: true, isStrictToggle: true };
      renderStrictVerifySection();
    } else if (type === 'operations') {
      const ops = generateOperations(strictMode.method?.count || 5, strictMode.method?.ascending !== false);
      pauseState['__strict__'] = { step: 'operations', ops, opIdx: 0, restart_on_fail: strictMode.method?.restart_on_fail || false, isStrictToggle: true };
      renderStrictVerifySection();
    }
  } else {
    await doStrictToggle();
  }
}

async function doStrictToggle() {
  const { userToken } = await chrome.storage.local.get('userToken');
  try {
    const res = await fetch(`${API_BASE}/pomodoro/strict-mode/toggle`, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${userToken}`, 'Content-Type': 'application/json' },
    });
    const data = await res.json();
    if (!res.ok) return;
    strictMode = { ...strictMode, enabled: data.enabled };
    delete pauseState['__strict__'];
    renderStrictModeToggle();
    renderSessions();
    renderStrictVerifySection();
  } catch(e) { console.warn('StrictToggle:', e.message); }
}

function renderStrictVerifySection() {
  const el = document.getElementById('strictVerifySection');
  if (!el) return;
  const state = pauseState['__strict__'];
  if (!state) { el.innerHTML = ''; el.style.display = 'none'; return; }
  el.style.display = 'block';
  let html = '';
  if (state.step === 'email-send') {
    html = `<div style="margin-top:8px;padding:8px;background:#1a1a1a;border-radius:8px;border:1px solid #3f3f46">
      <p style="font-size:0.7rem;color:#71717a;margin-bottom:6px">Necesitas desactivar el modo estricto</p>
      <button class="btn-activate" data-action="strictEmailSend" style="width:100%">${state.loading ? 'Enviando…' : 'Enviar código al email'}</button>
      ${state.err ? `<p class="pause-err">${state.err}</p>` : ''}
    </div>`;
  } else if (state.step === 'email-code') {
    html = `<div style="margin-top:8px;padding:8px;background:#1a1a1a;border-radius:8px;border:1px solid #3f3f46">
      <p style="font-size:0.7rem;color:#71717a;margin-bottom:4px">Código enviado a ${state.sentEmail}</p>
      <div style="display:flex;gap:6px">
        <input class="pause-input" data-action-input="strictVerifyCode" data-autofocus
          type="text" maxlength="6" placeholder="XXXXXX"
          style="flex:1;text-align:center;letter-spacing:4px;font-family:monospace" />
        <button class="btn-activate" data-action="strictVerifyCode">OK</button>
      </div>
      ${state.err ? `<p class="pause-err">${state.err}</p>` : ''}
    </div>`;
  } else if (state.step === 'operations') {
    const op = state.ops[state.opIdx];
    const dots = state.ops.map((_,i) =>
      `<div class="op-dot" style="background:${i<state.opIdx?'#4ade80':i===state.opIdx?'#fff':'#3f3f46'}"></div>`
    ).join('');
    html = `<div style="margin-top:8px;padding:8px;background:#1a1a1a;border-radius:8px;border:1px solid #3f3f46">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px">
        <span style="font-size:0.7rem;color:#71717a">Modo estricto: ${state.opIdx+1}/${state.ops.length}</span>
        <div class="op-dots">${dots}</div>
      </div>
      <p style="font-size:1.1rem;font-weight:700;font-family:monospace;text-align:center;margin:4px 0">${op.q} = ?</p>
      <div style="display:flex;gap:6px">
        <input class="pause-input" data-action-input="strictCheckOp" data-autofocus
          type="number" placeholder="?" style="flex:1;text-align:center" />
        <button class="btn-activate" data-action="strictCheckOp">${state.opIdx+1>=state.ops.length?'Confirmar':'→'}</button>
      </div>
      ${state.err ? `<p class="pause-err">${state.err}</p>` : ''}
    </div>`;
  }
  el.innerHTML = html;
  setTimeout(() => {
    const inp = el.querySelector('[data-autofocus]');
    if (inp) inp.focus();
  }, 30);
}

async function strictEmailSend() {
  pauseState['__strict__'] = { ...pauseState['__strict__'], loading: true };
  renderStrictVerifySection();
  const { userToken } = await chrome.storage.local.get('userToken');
  try {
    const res = await fetch(`${API_BASE}/pomodoro/strict-mode/request-code`, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${userToken}`, 'Content-Type': 'application/json' },
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Error');
    pauseState['__strict__'] = { ...pauseState['__strict__'], step: 'email-code', sentEmail: data.email, loading: false };
  } catch(e) { pauseState['__strict__'] = { ...pauseState['__strict__'], loading: false, err: e.message }; }
  renderStrictVerifySection();
}

async function strictVerifyCodeAction() {
  const inp = document.querySelector('[data-action-input="strictVerifyCode"]');
  const code = inp?.value?.trim();
  if (!code || code.length < 6) return;
  const { userToken } = await chrome.storage.local.get('userToken');
  try {
    const res = await fetch(`${API_BASE}/pomodoro/strict-mode/verify-code`, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${userToken}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ code }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Error');
    await doStrictToggle();
  } catch(e) { pauseState['__strict__'] = { ...pauseState['__strict__'], err: e.message }; renderStrictVerifySection(); }
}

async function strictCheckOp() {
  const inp = document.querySelector('[data-action-input="strictCheckOp"]');
  const val = parseInt(inp?.value?.trim(), 10);
  const state = pauseState['__strict__'];
  const op = state.ops[state.opIdx];
  if (isNaN(val) || val !== op.a) {
    if (state.restart_on_fail) pauseState['__strict__'] = { ...state, opIdx: 0, err: 'Incorrecto. Reiniciando.' };
    else pauseState['__strict__'] = { ...state, err: 'Respuesta incorrecta.' };
    renderStrictVerifySection(); return;
  }
  if (state.opIdx + 1 >= state.ops.length) { await doStrictToggle(); return; }
  pauseState['__strict__'] = { ...state, opIdx: state.opIdx + 1, err: null };
  renderStrictVerifySection();
}

document.getElementById('strictModeToggle').addEventListener('click', handleStrictToggle);

// ── Add URL ───────────────────────────────────────────────────────────────────
addUrlBtn.addEventListener('click', async () => {
  const pomodoroId = pomSelect.value;
  if (!pomodoroId || !currentTab?.url) return;

  const urlToAdd = getUrlToAdd(currentTab.url);
  setFeedback('Añadiendo…');
  addUrlBtn.disabled = true;

  try {
    const { userToken } = await chrome.storage.local.get('userToken');
    const res = await fetch(`${API_BASE}/pomodoro/my-pomodoros/${pomodoroId}/add-url`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${userToken}`,
      },
      body: JSON.stringify({ url: urlToAdd, wildcard: wildcardMode }),
    });
    const data = await res.json();

    if (!res.ok) throw new Error(data.error || 'Error');

    setFeedback(data.already ? 'Ya estaba añadida' : '✓ Añadida correctamente', 'success');
    chrome.runtime.sendMessage({ type: 'refresh' });
  } catch (e) {
    setFeedback(e.message || 'Error al añadir', 'error');
  } finally {
    addUrlBtn.disabled = false;
  }
});
