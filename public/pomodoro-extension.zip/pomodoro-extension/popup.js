const statusEl = document.getElementById('status');
const countdownEl = document.getElementById('countdown');
const urlsEl = document.getElementById('urls');

function formatTime(ms) {
  if (ms <= 0) return '00:00';
  const totalSeconds = Math.floor(ms / 1000);
  const m = Math.floor(totalSeconds / 60).toString().padStart(2, '0');
  const s = (totalSeconds % 60).toString().padStart(2, '0');
  return `${m}:${s}`;
}

function render({ active, ends_at, blocked_urls }) {
  if (active && ends_at) {
    const remaining = new Date(ends_at).getTime() - Date.now();
    if (remaining > 0) {
      statusEl.textContent = 'Modo trabajo activo';
      statusEl.classList.add('active');
      countdownEl.textContent = formatTime(remaining);
    } else {
      statusEl.textContent = 'Sesion terminada';
      statusEl.classList.remove('active');
      countdownEl.textContent = '';
    }
  } else {
    statusEl.textContent = 'Inactivo';
    statusEl.classList.remove('active');
    countdownEl.textContent = '';
  }

  urlsEl.innerHTML = (blocked_urls || [])
    .map(u => `<span>${u}</span>`)
    .join('');
}

chrome.storage.local.get(['active', 'ends_at', 'blocked_urls'], render);

// Actualiza countdown cada segundo
setInterval(() => {
  chrome.storage.local.get(['active', 'ends_at', 'blocked_urls'], render);
}, 1000);
