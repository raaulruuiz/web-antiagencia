function fmt(ms) {
  if (ms <= 0) return '00:00';
  const s = Math.floor(ms / 1000);
  const m = Math.floor(s / 60).toString().padStart(2, '0');
  const sec = (s % 60).toString().padStart(2, '0');
  return m + ':' + sec;
}

function tick() {
  chrome.storage.local.get(['ends_at'], ({ ends_at }) => {
    if (!ends_at) return;
    document.getElementById('countdown').textContent = fmt(new Date(ends_at).getTime() - Date.now());
  });
}

tick();
setInterval(tick, 1000);
