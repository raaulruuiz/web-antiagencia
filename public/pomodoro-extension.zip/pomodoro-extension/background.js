const API_URL = 'https://automatizaciones-production-a376.up.railway.app/pomodoro/status';

function extractRootDomain(input) {
  let d = input.replace(/^https?:\/\//, '');
  d = d.replace(/^www\./, '');
  d = d.split('/')[0];
  d = d.split(':')[0];
  return d;
}

// blocked_urls: [{url: string, wildcard: boolean}]
async function updateBlockRules(active, blocked_urls) {
  const existing = await chrome.declarativeNetRequest.getDynamicRules();
  const removeRuleIds = existing.map(r => r.id);

  if (!active || !blocked_urls || blocked_urls.length === 0) {
    console.log('[Pomodoro] Eliminando reglas de bloqueo');
    await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds });
    return;
  }

  const blockedPageUrl = chrome.runtime.getURL('blocked.html');

  const addRules = blocked_urls.map((entry, i) => {
    const url = typeof entry === 'string' ? entry : entry.url;
    const wildcard = typeof entry === 'string' ? true : (entry.wildcard ?? true);

    if (wildcard) {
      const rootDomain = extractRootDomain(url);
      return {
        id: i + 1,
        priority: 1,
        action: { type: 'redirect', redirect: { url: blockedPageUrl } },
        condition: { requestDomains: [rootDomain], resourceTypes: ['main_frame'] },
      };
    } else {
      const clean = url.replace(/^https?:\/\//, '').replace(/^www\./, '');
      return {
        id: i + 1,
        priority: 1,
        action: { type: 'redirect', redirect: { url: blockedPageUrl } },
        condition: { urlFilter: `||${clean}`, resourceTypes: ['main_frame'] },
      };
    }
  });

  console.log('[Pomodoro] Aplicando reglas:', addRules.map(r =>
    r.condition.requestDomains ? `wildcard:${r.condition.requestDomains[0]}` : `exact:${r.condition.urlFilter}`
  ));
  await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds, addRules });
}

async function fetchStatus() {
  console.log('[Pomodoro] fetchStatus iniciado');
  try {
    const res = await fetch(API_URL);
    if (!res.ok) { console.warn('[Pomodoro] API error:', res.status); return; }
    const data = await res.json();
    console.log('[Pomodoro] Estado recibido:', data);

    const active = data.active || false;
    const blocked_urls = data.blocked_urls || [];
    const ends_at = data.ends_at || null;

    await chrome.storage.local.set({ active, blocked_urls, ends_at });
    await updateBlockRules(active, blocked_urls);
  } catch (e) {
    console.error('[Pomodoro] Error en fetch:', e.message);
  }
}

chrome.alarms.create('poll', { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'poll') { console.log('[Pomodoro] Alarm disparado'); fetchStatus(); }
});

let lastFetch = 0;
chrome.webNavigation.onBeforeNavigate.addListener((details) => {
  if (details.frameId !== 0) return;
  const now = Date.now();
  console.log('[Pomodoro] Navegación detectada:', details.url.slice(0, 60));
  if (now - lastFetch < 5000) { console.log('[Pomodoro] Throttled, saltando fetch'); return; }
  lastFetch = now;
  fetchStatus();
});

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'refresh') {
    console.log('[Pomodoro] Refresh directo desde admin');
    lastFetch = 0;
    fetchStatus();
  }
});

console.log('[Pomodoro] Service worker iniciado');
fetchStatus();
