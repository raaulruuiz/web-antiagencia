const API_URL = 'https://automatizaciones-production-a376.up.railway.app/pomodoro/status';

async function updateBlockRules(active, blocked_urls) {
  const existing = await chrome.declarativeNetRequest.getDynamicRules();
  const removeRuleIds = existing.map(r => r.id);

  if (!active || !blocked_urls || blocked_urls.length === 0) {
    console.log('[Pomodoro] Eliminando reglas de bloqueo');
    await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds });
    return;
  }

  const blockedPageUrl = chrome.runtime.getURL('blocked.html');
  const addRules = blocked_urls.map((domain, i) => ({
    id: i + 1,
    priority: 1,
    action: { type: 'redirect', redirect: { url: blockedPageUrl } },
    condition: {
      urlFilter: `||${domain.replace(/^www\./, '')}`,
      resourceTypes: ['main_frame']
    }
  }));

  console.log('[Pomodoro] Aplicando reglas:', addRules.map(r => r.condition.urlFilter));
  await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds, addRules });
}

async function fetchStatus() {
  console.log('[Pomodoro] fetchStatus iniciado');
  try {
    const res = await fetch(API_URL);
    if (!res.ok) { console.warn('[Pomodoro] API error:', res.status); return; }
    const data = await res.json();
    console.log('[Pomodoro] Estado recibido:', data);

    const active = data.active || false;
    const blocked_urls = data.blocked_urls || [];
    const ends_at = data.ends_at || null;

    await chrome.storage.local.set({ active, blocked_urls, ends_at });
    await updateBlockRules(active, blocked_urls);
  } catch (e) {
    console.error('[Pomodoro] Error en fetch:', e.message);
  }
}

// Alarm de respaldo (MV3 mínimo: 1 minuto)
chrome.alarms.create('poll', { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'poll') { console.log('[Pomodoro] Alarm disparado'); fetchStatus(); }
});

// Cada navegación principal reactiva el service worker y refresca
let lastFetch = 0;
chrome.webNavigation.onBeforeNavigate.addListener((details) => {
  if (details.frameId !== 0) return;
  const now = Date.now();
  console.log('[Pomodoro] Navegación detectada:', details.url.slice(0, 60));
  if (now - lastFetch < 5000) { console.log('[Pomodoro] Throttled, saltando fetch'); return; }
  lastFetch = now;
  fetchStatus();
});

// Mensaje directo desde la página de admin (instantáneo)
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'refresh') {
    console.log('[Pomodoro] Refresh directo desde admin');
    lastFetch = 0; // forzar fetch aunque esté en throttle
    fetchStatus();
  }
});

console.log('[Pomodoro] Service worker iniciado');
fetchStatus();
