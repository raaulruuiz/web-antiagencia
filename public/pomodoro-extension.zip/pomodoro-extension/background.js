const API_URL  = 'https://automatizaciones-production-a376.up.railway.app/pomodoro/status';
const API_BASE = 'https://automatizaciones-production-a376.up.railway.app';
const SUPABASE_URL = 'https://wphvmyqsxicyoifrlevt.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_cB3mpag9moVvhekQG6GBWw_ogz_nb9M';

function extractRootDomain(input) {
  let d = input.replace(/^https?:\/\//, '');
  d = d.replace(/^www\./, '');
  d = d.split('/')[0];
  d = d.split(':')[0];
  return d;
}

// Read fresh session from antiagencia.es tab (avoids competing with web for refresh tokens)
async function getSessionFromTab() {
  try {
    const tabs = await chrome.tabs.query({ url: '*://antiagencia.es/*' });
    if (!tabs.length) return null;
    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId: tabs[0].id },
      func: () => {
        try {
          for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (key && (key.startsWith('sb-') || key.includes('supabase')) && key.endsWith('-auth-token')) {
              const raw = localStorage.getItem(key);
              if (!raw) continue;
              const s = JSON.parse(raw);
              if (s?.access_token) return {
                token: s.access_token,
                refreshToken: s.refresh_token,
                expiresAt: s.expires_at ? s.expires_at * 1000 - 60000 : null,
              };
            }
          }
        } catch (_) {}
        return null;
      },
    });
    return result || null;
  } catch (_) { return null; }
}

async function getValidToken() {
  // 1. Prefer live session from antiagencia.es tab — no independent refresh needed
  const tabSession = await getSessionFromTab();
  if (tabSession?.token) {
    await chrome.storage.local.set({
      userToken:        tabSession.token,
      userRefreshToken: tabSession.refreshToken,
      userTokenExpiry:  tabSession.expiresAt,
    });
    return tabSession.token;
  }

  // 2. Fall back to stored token (e.g., tab not open)
  const { userToken, userRefreshToken, userTokenExpiry } = await chrome.storage.local.get([
    'userToken', 'userRefreshToken', 'userTokenExpiry'
  ]);

  if (!userToken) return null;

  // Only refresh independently if token is expired and tab is not available
  if (userTokenExpiry && Date.now() >= userTokenExpiry) {
    if (!userRefreshToken) return null;
    try {
      const res = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=refresh_token`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'apikey': SUPABASE_ANON_KEY },
        body: JSON.stringify({ refresh_token: userRefreshToken }),
      });
      const data = await res.json();
      if (!res.ok || !data.access_token) {
        await chrome.storage.local.remove(['userToken', 'userRefreshToken', 'userEmail', 'userTokenExpiry']);
        return null;
      }
      await chrome.storage.local.set({
        userToken:        data.access_token,
        userRefreshToken: data.refresh_token,
        userTokenExpiry:  Date.now() + (data.expires_in - 60) * 1000,
      });
      return data.access_token;
    } catch {
      return null;
    }
  }

  return userToken;
}

async function updateBlockRules(active, blocked_urls) {
  const existing = await chrome.declarativeNetRequest.getDynamicRules();
  const removeRuleIds = existing.map(r => r.id);

  if (!active || !blocked_urls || blocked_urls.length === 0) {
    await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds });
    return;
  }

  const blockedPageUrl = chrome.runtime.getURL('blocked.html');

  const addRules = [];
  let ruleId = 1;
  blocked_urls.forEach((entry) => {
    const url = typeof entry === 'string' ? entry : entry.url;
    const wildcard = typeof entry === 'string' ? true : (entry.wildcard ?? true);

    if (wildcard) {
      const domain = extractRootDomain(url);
      // requestDomains matches the domain AND all its subdomains (Chrome 98+)
      addRules.push({
        id: ruleId++, priority: 1,
        action: { type: 'redirect', redirect: { url: blockedPageUrl } },
        condition: { requestDomains: [domain], resourceTypes: ['main_frame'] },
      });
    } else {
      const clean = url.replace(/^https?:\/\//, '').replace(/^www\./, '');
      addRules.push({
        id: ruleId++, priority: 1,
        action: { type: 'redirect', redirect: { url: blockedPageUrl } },
        condition: { urlFilter: `||${clean}`, resourceTypes: ['main_frame'] },
      });
    }
  });

  await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds, addRules });
}

// Checks if a URL is covered by the blocked_urls list (wildcard-aware)
function isUrlBlocked(url, blockedUrls) {
  if (!blockedUrls || !blockedUrls.length) return false;
  try {
    const hostname = new URL(url).hostname.replace(/^www\./, '');
    return blockedUrls.some(entry => {
      const entryUrl = typeof entry === 'string' ? entry : entry.url;
      const wildcard = typeof entry === 'string' ? true : (entry.wildcard ?? true);
      const domain = extractRootDomain(entryUrl);
      if (wildcard) {
        return hostname === domain || hostname.endsWith('.' + domain);
      } else {
        const clean = entryUrl.replace(/^https?:\/\//, '').replace(/^www\./, '');
        const urlClean = url.replace(/^https?:\/\//, '').replace(/^www\./, '').split('#')[0];
        return urlClean.startsWith(clean);
      }
    });
  } catch { return false; }
}

// Fallback blocker: catches SW-cached refreshes (Cmd+R) and bfcache restores
// that bypass declarativeNetRequest
chrome.webNavigation.onCommitted.addListener(async (details) => {
  if (details.frameId !== 0) return;
  const { active, blocked_urls } = await chrome.storage.local.get(['active', 'blocked_urls']);
  if (!active || !blocked_urls?.length) return;
  if (isUrlBlocked(details.url, blocked_urls)) {
    chrome.tabs.update(details.tabId, { url: chrome.runtime.getURL('blocked.html') });
  }
}, { url: [{ schemes: ['http', 'https'] }] });

async function fetchStatus(retry = true) {
  try {
    const token = await getValidToken();
    const headers = token ? { 'Authorization': `Bearer ${token}` } : {};

    const res = await fetch(API_URL, { headers });
    if (!res.ok) { console.warn('[Pomodoro] API error:', res.status); return; }
    const data = await res.json();

    const active = data.active || false;
    const blocked_urls = data.blocked_urls || [];
    const ends_at = data.ends_at || null;
    const has_biblioteca = data.has_biblioteca || false;

    await chrome.storage.local.set({ active, blocked_urls, ends_at, has_biblioteca });
    await updateBlockRules(active, blocked_urls);

    // Redirect any already-open tabs that are on blocked URLs
    if (active && blocked_urls.length > 0) {
      try {
        const blockedPageUrl = chrome.runtime.getURL('blocked.html');
        const tabs = await chrome.tabs.query({});
        for (const tab of tabs) {
          if (tab.url && tab.url.startsWith('http') && isUrlBlocked(tab.url, blocked_urls)) {
            chrome.tabs.update(tab.id, { url: blockedPageUrl }).catch(() => {});
          }
        }
      } catch (_) {}
    }
  } catch (e) {
    if (retry) {
      // Railway cold-start can take up to 30s — retry once after 25s
      setTimeout(() => fetchStatus(false), 25000);
    } else {
      console.log('[Pomodoro] fetch failed after retry:', e.message);
    }
  }
}

chrome.alarms.create('poll', { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'poll') fetchStatus();
});

let lastFetch = 0;
chrome.webNavigation.onBeforeNavigate.addListener((details) => {
  if (details.frameId !== 0) return;
  const now = Date.now();
  if (now - lastFetch < 5000) return;
  lastFetch = now;
  fetchStatus();
});

// ── Biblioteca helpers ────────────────────────────────────────────────────────

async function uploadBibliotecaFile(blob, filename) {
  const { userToken } = await chrome.storage.local.get('userToken');
  if (!userToken) throw new Error('No hay sesión');
  const fd = new FormData();
  fd.append('file', blob, filename);
  const res = await fetch(`${API_BASE}/biblioteca/upload`, {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${userToken}` },
    body: fd,
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Error al subir');
  return data;
}

async function captureFullPageBlob(tabId, windowId) {
  const [{ result: info }] = await chrome.scripting.executeScript({
    target: { tabId },
    func: () => {
      const viewH = window.innerHeight;
      const viewW = window.innerWidth;
      const dpr   = window.devicePixelRatio || 1;
      const winScrollH = Math.max(document.documentElement.scrollHeight, document.body?.scrollHeight || 0);

      // Si la ventana scrollea normalmente, modo estándar
      if (winScrollH > viewH + 10) {
        return { scrollH: winScrollH, viewH, viewW, dpr, origY: window.scrollY, useScrollEl: false, rect: null };
      }

      // La ventana no scrollea (Gmail, Notion, etc.) → buscar el contenedor scrollable más grande
      let best = null, bestSH = 0;
      for (const el of document.querySelectorAll('*')) {
        if (el === document.body || el === document.documentElement) continue;
        const st = window.getComputedStyle(el);
        if (!/auto|scroll/.test(st.overflow + st.overflowY)) continue;
        const sh = el.scrollHeight, ch = el.clientHeight;
        if (sh > ch + 20 && sh > bestSH) { bestSH = sh; best = el; }
      }

      if (best) {
        window.__bibScrollEl = best;
        const r = best.getBoundingClientRect();
        return {
          scrollH: best.scrollHeight,
          viewH: Math.round(r.height),
          viewW: Math.round(r.width),
          dpr, origY: best.scrollTop, useScrollEl: true,
          rect: { x: Math.round(r.left), y: Math.round(r.top), w: Math.round(r.width), h: Math.round(r.height) },
        };
      }

      return { scrollH: winScrollH, viewH, viewW, dpr, origY: window.scrollY, useScrollEl: false, rect: null };
    },
  });

  const { scrollH, viewH, viewW, dpr, origY, useScrollEl, rect } = info;
  const canvasW = (useScrollEl && rect) ? Math.round(rect.w * dpr) : Math.round(viewW * dpr);
  const canvas = new OffscreenCanvas(canvasW, Math.round(scrollH * dpr));
  const ctx = canvas.getContext('2d');

  // Oculta/muestra elementos fixed y sticky inyectando una clase CSS
  const setFixedHidden = (hide) => chrome.scripting.executeScript({
    target: { tabId },
    func: (hide) => {
      const STYLE_ID = '__bib_fixer__';
      if (hide) {
        if (!document.getElementById(STYLE_ID)) {
          const s = document.createElement('style');
          s.id = STYLE_ID;
          s.textContent = '.__bib_hide { visibility: hidden !important; }';
          document.head.appendChild(s);
        }
        document.querySelectorAll('*').forEach(el => {
          const pos = window.getComputedStyle(el).position;
          if (pos === 'fixed' || pos === 'sticky') el.classList.add('__bib_hide');
        });
      } else {
        document.querySelectorAll('.__bib_hide').forEach(el => el.classList.remove('__bib_hide'));
        document.getElementById(STYLE_ID)?.remove();
      }
    },
    args: [hide],
  });

  let targetY = 0;
  let isFirst = true;
  const seen = new Set();

  while (targetY < scrollH) {
    const [{ result: actualY }] = await chrome.scripting.executeScript({
      target: { tabId },
      func: (y, useEl) => {
        if (useEl && window.__bibScrollEl) {
          window.__bibScrollEl.scrollTop = y;
          return window.__bibScrollEl.scrollTop;
        }
        window.scrollTo(0, y);
        return window.scrollY;
      },
      args: [targetY, useScrollEl],
    });
    if (seen.has(actualY) && targetY > 0) break;
    seen.add(actualY);

    await new Promise(r => setTimeout(r, 150));

    // Ocultar fixed/sticky en todos los fragmentos
    await setFixedHidden(true);
    await new Promise(r => setTimeout(r, 80)); // repaint

    const dataUrl = await chrome.tabs.captureVisibleTab(windowId, { format: 'png' });

    await setFixedHidden(false);

    const blob = await (await fetch(dataUrl)).blob();
    let img;
    if (useScrollEl && rect) {
      // Recortar al área del contenedor scrollable (elimina sidebar/header de Gmail, etc.)
      img = await createImageBitmap(blob,
        Math.round(rect.x * dpr), Math.round(rect.y * dpr),
        Math.round(rect.w * dpr), Math.round(rect.h * dpr));
    } else {
      img = await createImageBitmap(blob);
    }
    ctx.drawImage(img, 0, Math.round(actualY * dpr));
    targetY += viewH;
    isFirst = false;
  }

  // Restaurar scroll y asegurarse de que no queden elementos ocultos
  await setFixedHidden(false);
  await chrome.scripting.executeScript({
    target: { tabId },
    func: (y, useEl) => {
      if (useEl && window.__bibScrollEl) window.__bibScrollEl.scrollTop = y;
      else window.scrollTo(0, y);
    },
    args: [origY, useScrollEl],
  });

  return canvas.convertToBlob({ type: 'image/png' });
}

async function cropImage(dataUrl, rect, dpr) {
  const img = await createImageBitmap(await (await fetch(dataUrl)).blob());
  const x = Math.round(rect.x * dpr);
  const y = Math.round(rect.y * dpr);
  const w = Math.round(rect.w * dpr);
  const h = Math.round(rect.h * dpr);
  const canvas = new OffscreenCanvas(w, h);
  canvas.getContext('2d').drawImage(img, -x, -y);
  return canvas.convertToBlob({ type: 'image/png' });
}

function injectSelectionOverlay() {
  const existing = document.getElementById('__bib_overlay__');
  if (existing) existing.remove();

  const overlay = document.createElement('div');
  overlay.id = '__bib_overlay__';
  Object.assign(overlay.style, {
    position: 'fixed', top: '0', left: '0',
    width: '100vw', height: '100vh',
    zIndex: '2147483647', cursor: 'crosshair',
    background: 'rgba(0,0,0,0.25)',
  });

  const sel = document.createElement('div');
  Object.assign(sel.style, {
    position: 'fixed', border: '2px solid #4ade80',
    background: 'rgba(74,222,128,0.08)', pointerEvents: 'none', display: 'none',
  });
  overlay.appendChild(sel);

  let sx, sy, drawing = false;

  overlay.addEventListener('mousedown', e => {
    e.preventDefault();
    sx = e.clientX; sy = e.clientY; drawing = true;
    sel.style.display = 'block';
    sel.style.left = sx + 'px'; sel.style.top = sy + 'px';
    sel.style.width = '0'; sel.style.height = '0';
  });

  overlay.addEventListener('mousemove', e => {
    if (!drawing) return;
    const x = Math.min(e.clientX, sx), y = Math.min(e.clientY, sy);
    sel.style.left = x + 'px'; sel.style.top = y + 'px';
    sel.style.width = Math.abs(e.clientX - sx) + 'px';
    sel.style.height = Math.abs(e.clientY - sy) + 'px';
  });

  overlay.addEventListener('mouseup', e => {
    if (!drawing) return;
    drawing = false;
    const x = Math.min(e.clientX, sx), y = Math.min(e.clientY, sy);
    const w = Math.abs(e.clientX - sx), h = Math.abs(e.clientY - sy);
    overlay.remove();
    if (w > 10 && h > 10) {
      chrome.runtime.sendMessage({ type: 'selectionDone', rect: { x, y, w, h }, dpr: window.devicePixelRatio || 1 });
    }
  });

  const onKey = e => { if (e.key === 'Escape') { overlay.remove(); document.removeEventListener('keydown', onKey); } };
  document.addEventListener('keydown', onKey);
  document.body.appendChild(overlay);
}

function setBibBadge(ok) {
  chrome.action.setBadgeText({ text: ok ? '✓' : '!' });
  chrome.action.setBadgeBackgroundColor({ color: ok ? '#4ade80' : '#f87171' });
  setTimeout(() => chrome.action.setBadgeText({ text: '' }), 3000);
}

// ── Image viewer relay (in-memory, no storage size limits) ───────────────────
let bibViewerImageData = null;

// ── Message listener ──────────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'setBibViewerImage') {
    bibViewerImageData = msg.data;
    sendResponse({ ok: true });
    return true;
  }
  if (msg.type === 'getBibViewerImage') {
    sendResponse({ ok: true, data: bibViewerImageData });
    bibViewerImageData = null;
    return true;
  }
  if (msg.type === 'getValidToken') {
    (async () => {
      const token = await getValidToken();
      sendResponse({ token });
    })();
    return true;
  }
  if (msg.type === 'refresh') {
    lastFetch = 0;
    fetchStatus();
  }
  if (msg.type === 'setSession') {
    chrome.storage.local.set({
      userToken:        msg.token,
      userRefreshToken: msg.refreshToken,
      userEmail:        msg.email,
      userTokenExpiry:  msg.expiresAt || null,
    }).then(() => { lastFetch = 0; fetchStatus(); });
  }
  if (msg.type === 'clearSession') {
    chrome.storage.local.remove(['userToken', 'userRefreshToken', 'userEmail', 'userTokenExpiry'])
      .then(() => { lastFetch = 0; fetchStatus(); });
  }
  if (msg.type === 'bibCaptureVisible') {
    (async () => {
      try {
        const dataUrl = await chrome.tabs.captureVisibleTab(msg.windowId, { format: 'png' });
        const blob = await (await fetch(dataUrl)).blob();
        const data = await uploadBibliotecaFile(blob, `visible_${Date.now()}.png`);
        sendResponse({ ok: true, id: data.id });
      } catch(e) {
        console.error('[Biblioteca] visible error:', e.message);
        sendResponse({ ok: false, error: e.message });
      }
    })();
    return true;
  }
  if (msg.type === 'bibCaptureVisibleOnly') {
    (async () => {
      try {
        const dataUrl = await chrome.tabs.captureVisibleTab(msg.windowId, { format: 'png' });
        sendResponse({ ok: true, dataUrl });
      } catch(e) {
        sendResponse({ ok: false, error: e.message });
      }
    })();
    return true;
  }
  if (msg.type === 'bibCaptureFullPage') {
    (async () => {
      try {
        const blob = await captureFullPageBlob(msg.tabId, msg.windowId);
        const data = await uploadBibliotecaFile(blob, `fullpage_${Date.now()}.png`);
        sendResponse({ ok: true, id: data.id });
      } catch(e) {
        console.error('[Biblioteca] full page error:', e.message);
        sendResponse({ ok: false, error: e.message });
      }
    })();
    return true;
  }
  if (msg.type === 'bibCaptureFullPageOnly') {
    (async () => {
      try {
        const blob = await captureFullPageBlob(msg.tabId, msg.windowId);
        const dataUrl = await new Promise((res, rej) => {
          const reader = new FileReader();
          reader.onload = () => res(reader.result);
          reader.onerror = rej;
          reader.readAsDataURL(blob);
        });
        sendResponse({ ok: true, dataUrl });
      } catch(e) {
        sendResponse({ ok: false, error: e.message });
      }
    })();
    return true;
  }
  if (msg.type === 'bibUploadFile') {
    (async () => {
      try {
        const blob = await (await fetch(msg.dataUrl)).blob();
        const data = await uploadBibliotecaFile(blob, msg.name || `imagen_${Date.now()}`);
        sendResponse({ ok: true, id: data.id });
      } catch(e) {
        console.error('[Biblioteca] upload file error:', e.message);
        sendResponse({ ok: false, error: e.message });
      }
    })();
    return true;
  }
  if (msg.type === 'bibStartSelection') {
    chrome.scripting.executeScript({
      target: { tabId: msg.tabId },
      func: injectSelectionOverlay,
    }).catch(e => console.error('[Biblioteca] inject overlay error:', e.message));
  }
  if (msg.type === 'selectionDone') {
    (async () => {
      try {
        const dataUrl = await chrome.tabs.captureVisibleTab(sender.tab?.windowId, { format: 'png' });
        const blob = await cropImage(dataUrl, msg.rect, msg.dpr);
        const { bibDirectMode } = await chrome.storage.local.get('bibDirectMode');
        if (bibDirectMode === false) {
          const pendingDataUrl = await new Promise((res, rej) => {
            const reader = new FileReader();
            reader.onload = () => res(reader.result);
            reader.onerror = rej;
            reader.readAsDataURL(blob);
          });
          await chrome.storage.local.set({ bibPendingCapture: { dataUrl: pendingDataUrl, filename: `area_${Date.now()}.png` } });
          try { await chrome.action.openPopup(); } catch(_) { setBibBadge(true); }
        } else {
          const data = await uploadBibliotecaFile(blob, `area_${Date.now()}.png`);
          setBibBadge(true);
          chrome.tabs.create({ url: `https://antiagencia.es/admin/biblioteca/${data.id}` });
        }
      } catch(e) {
        console.error('[Biblioteca] selection error:', e.message);
        setBibBadge(false);
      }
    })();
  }
});

setTimeout(fetchStatus, 2000);
