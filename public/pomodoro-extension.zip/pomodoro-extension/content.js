window.addEventListener('pomodoroRefresh', () => {
  try {
    chrome.runtime.sendMessage({ type: 'refresh' });
  } catch (_) {
    // Extension context invalidated (reloaded/updated) — ignorar
  }
});
