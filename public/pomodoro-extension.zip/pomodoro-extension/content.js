window.addEventListener('pomodoroRefresh', () => {
  chrome.runtime.sendMessage({ type: 'refresh' });
});
