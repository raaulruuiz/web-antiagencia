// Sync Supabase session from the admin page to the extension automatically
function findSupabaseSession() {
  try {
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && (key.startsWith('sb-') || key.includes('supabase')) && key.endsWith('-auth-token')) {
        const raw = localStorage.getItem(key);
        if (!raw) continue;
        const session = JSON.parse(raw);
        if (session?.access_token) return session;
      }
    }
  } catch (_) {}
  return null;
}

function syncSession() {
  try {
    const session = findSupabaseSession();
    if (session) {
      chrome.runtime.sendMessage({
        type: 'setSession',
        token: session.access_token,
        refreshToken: session.refresh_token,
        email: session.user?.email,
        // expires_at is in seconds, convert to ms with 60s margin
        expiresAt: session.expires_at ? session.expires_at * 1000 - 60000 : null,
      });
    } else {
      // No session in localStorage — user logged out
      chrome.runtime.sendMessage({ type: 'clearSession' });
    }
  } catch (_) {
    // Extension context invalidated (reloaded/updated) — ignore
  }
}

// Sync immediately on page load (localStorage already has the persisted session)
syncSession();

// Sync when another tab changes localStorage (cross-tab login/logout)
window.addEventListener('storage', (e) => {
  if (e.key && (e.key.startsWith('sb-') || e.key.includes('supabase'))) {
    try { syncSession(); } catch (_) {}
  }
});

// Forward admin page signals to the extension background
window.addEventListener('pomodoroRefresh', () => {
  try {
    chrome.runtime.sendMessage({ type: 'refresh' });
  } catch (_) {}
});

// Bridge: web page → extension for silent captures (used by /admin/loom)
window.addEventListener('message', (e) => {
  if (e.source !== window || e.data?.source !== 'antiagencia-page') return;
  try {
    if (e.data.type === 'bibCaptureRequest') {
      chrome.runtime.sendMessage({ type: 'bibCaptureForPage', mode: e.data.mode }, (resp) => {
        if (chrome.runtime.lastError) {
          window.postMessage({ source: 'antiagencia-ext', type: 'bibCaptureResponse', ok: false, error: 'Extension unavailable' }, '*');
          return;
        }
        window.postMessage({ source: 'antiagencia-ext', type: 'bibCaptureResponse', ...(resp || { ok: false }) }, '*');
      });
    }
    if (e.data.type === 'bibAreaCaptureRequest') {
      chrome.runtime.sendMessage({ type: 'bibAreaCaptureForPage' });
    }
  } catch (_) {}
});

// Relay area capture result from background to web page
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'bibAreaCaptureResult') {
    window.postMessage({ source: 'antiagencia-ext', type: 'bibCaptureResponse', ok: msg.ok, dataUrl: msg.dataUrl, error: msg.error }, '*');
  }
  return true;
});

// Respond to popup asking for the current session
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type === 'getSession') {
    const session = findSupabaseSession();
    sendResponse(session ? {
      token: session.access_token,
      refreshToken: session.refresh_token,
      email: session.user?.email,
      expiresAt: session.expires_at ? session.expires_at * 1000 - 60000 : null,
    } : null);
  }
  return true;
});
